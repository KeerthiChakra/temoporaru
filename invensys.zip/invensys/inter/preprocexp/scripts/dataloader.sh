#!/bin/bash
COBOL_COMPILER=/usr/bin/cobc
COBOL_RUNTIME=/usr/bin/cobrun
COBOL_PROGRAM=LoadData.cbl
INPUT_FILE=input.dat
LOG_FILE=log-$(date +'%Y%m%d-%H%M%S').log
$COBOL_COMPILER -x $COBOL_PROGRAM
$COBOL_RUNTIME LoadData $INPUT_FILE $LOG_FILE
if [ $? -ne 0 ]; then
    echo "Error running COBOL program"
    exit 1
fi
if [ ! -f $LOG_FILE ]; then
    echo "Error creating log file"
    exit 1
fi
if grep -q "Error" $LOG_FILE; then
    echo "Error in log file"
    exit 1
fi
exit 0
