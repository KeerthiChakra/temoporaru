#!/bin/bash

# Set the path to the COBOL compiler and runtime environment
COBOL_COMPILER=/usr/bin/cobc
COBOL_RUNTIME=/usr/bin/cobrun

# Set the path to the COBOL program
COBOL_PROGRAM=LoadData.cbl

# Set the path to the input file
INPUT_FILE=input.dat

# Set the path to the log file
LOG_FILE=log-$(date +'%Y%m%d-%H%M%S').log

# Compile the COBOL program
$COBOL_COMPILER -x $COBOL_PROGRAM

# Run the COBOL program
$COBOL_RUNTIME LoadData $INPUT_FILE $LOG_FILE

# Check the exit status of the program
if [ $? -ne 0 ]; then
    echo "Error running COBOL program"
    exit 1
fi

# Check if the log file was created
if [ ! -f $LOG_FILE ]; then
    echo "Error creating log file"
    exit 1
fi

# Check the contents of the log file
if grep -q "Error" $LOG_FILE; then
    echo "Error in log file"
    exit 1
fi

# If everything is okay, exit with a status of 0
exit 0
