package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class MQMDTest {

    private MQMD mqmd;

    @BeforeEach
    public void setup() {
        mqmd = new MQMD();
    }

    // Test normal cases for getters and setters
    @ParameterizedTest
    @CsvSource({
            "test, 8",
            "shorter, 7",
            "longer, 9"
    })
    public void testSetFormat(String format, int length) {
        mqmd.setFormat(format);
        assertEquals(format, mqmd.getFormat());
    }

    // Test edge cases for setters
    @Test
    public void testSetFormatNull() {
        assertThrows(NullPointerException.class, () -> mqmd.setFormat(null));
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "   ", "\t"})
    public void testSetFormatEmpty(String format) {
        assertThrows(IllegalArgumentException.class, () -> mqmd.setFormat(format));
    }

    // Test version getter and setter
    @ParameterizedTest
    @CsvSource({
            "1",
            "-1"
    })
    public void testSetVersion(int version) {
        mqmd.setVersion(version);
        assertEquals(version, mqmd.getVersion());
    }

    // Test edge cases for setters
    @Test
    public void testSetVersionNegative() {
        assertThrows(IllegalArgumentException.class, () -> mqmd.setVersion(-1));
    }

    // Test msgId getter and setter
    @ParameterizedTest
    @CsvSource({
            "test, 24",
            "shorter, 23",
            "longer, 25"
    })
    public void testSetMsgId(String msgId, int length) {
        mqmd.setMsgId(msgId);
        assertEquals(msgId, mqmd.getMsgId());
    }

    // Test edge cases for setters
    @Test
    public void testSetMsgIdNull() {
        assertThrows(NullPointerException.class, () -> mqmd.setMsgId(null));
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "   ", "\t"})
    public void testSetMsgIdEmpty(String msgId) {
        assertThrows(IllegalArgumentException.class, () -> mqmd.setMsgId(msgId));
    }

    // Test correlId getter and setter
    @ParameterizedTest
    @CsvSource({
            "test, 24",
            "shorter, 23",
            "longer, 25"
    })
    public void testSetCorrelId(String correlId, int length) {
        mqmd.setCorrelId(correlId);
        assertEquals(correlId, mqmd.getCorrelId());
    }

    // Test edge cases for setters
    @Test
    public void testSetCorrelIdNull() {
        assertThrows(NullPointerException.class, () -> mqmd.setCorrelId(null));
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "   ", "\t"})
    public void testSetCorrelIdEmpty(String correlId) {
        assertThrows(IllegalArgumentException.class, () -> mqmd.setCorrelId(correlId));
    }

    // Test persistence getter and setter
    @ParameterizedTest
    @CsvSource({
            "1",
            "-1"
    })
    public void testSetPersistence(int persistence) {
        mqmd.setPersistence(persistence);
        assertEquals(persistence, mqmd.getPersistence());
    }

    // Test edge cases for setters
    @Test
    public void testSetPersistenceNegative() {
        assertThrows(IllegalArgumentException.class, () -> mqmd.setPersistence(-1));
    }

    // Test putTime getter and setter
    @ParameterizedTest
    @CsvSource({
            "test, 8",
            "shorter, 7",
            "longer, 9"
    })
    public void testSetPutTime(String putTime, int length) {
        mqmd.setPutTime(putTime);
        assertEquals(putTime, mqmd.getPutTime());
    }

    // Test edge cases for setters
    @Test
    public void testSetPutTimeNull() {
        assertThrows(NullPointerException.class, () -> mqmd.setPutTime(null));
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "   ", "\t"})
    public void testSetPutTimeEmpty(String putTime) {
        assertThrows(IllegalArgumentException.class, () -> mqmd.setPutTime(putTime));
    }

    // Test putDate getter and setter
    @ParameterizedTest
    @CsvSource({
            "test, 8",
            "shorter, 7",
            "longer, 9"
    })
    public void testSetPutDate(String putDate, int length) {
        mqmd.setPutDate(putDate);
        assertEquals(putDate, mqmd.getPutDate());
    }

    // Test edge cases for setters
    @Test
    public void testSetPutDateNull() {
        assertThrows(NullPointerException.class, () -> mqmd.setPutDate(null));
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "   ", "\t"})
    public void testSetPutDateEmpty(String putDate) {
        assertThrows(IllegalArgumentException.class, () -> mqmd.setPutDate(putDate));
    }
}