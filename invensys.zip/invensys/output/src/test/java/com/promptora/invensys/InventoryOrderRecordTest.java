package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class InventoryOrderRecordTest {

    private InventoryOrderRecord record;

    @BeforeEach
    public void setup() {
        record = new InventoryOrderRecord();
    }

    // Test getters and setters for normal cases

    @Test
    public void testGetProductId_DefaultValue() {
        assertEquals(null, record.getProductId());
    }

    @Test
    public void testSetAndGetProductId() {
        String productId = "ABC123";
        record.setProductId(productId);
        assertEquals(productId, record.getProductId());
    }

    @Test
    public void testGetStoreId_DefaultValue() {
        assertEquals(0, record.getStoreId());
    }

    @ParameterizedTest
    @CsvSource({
            "1",
            "100",
            "-10"
    })
    public void testSetAndGetStoreId(int storeId) {
        record.setStoreId(storeId);
        assertEquals(storeId, record.getStoreId());
    }

    @Test
    public void testGetOrderQuantity_DefaultValue() {
        assertEquals(0, record.getOrderQuantity());
    }

    @ParameterizedTest
    @CsvSource({
            "1",
            "100",
            "-10"
    })
    public void testSetAndGetOrderQuantity(int orderQuantity) {
        record.setOrderQuantity(orderQuantity);
        assertEquals(orderQuantity, record.getOrderQuantity());
    }

    // Test edge cases

    @Test
    public void testSetProductId_Null() {
        record.setProductId(null);
        assertEquals(null, record.getProductId());
    }

    @Test
    public void testSetStoreId_MinValue() {
        int minValue = Integer.MIN_VALUE;
        record.setStoreId(minValue);
        assertEquals(minValue, record.getStoreId());
    }

    @Test
    public void testSetStoreId_MaxValue() {
        int maxValue = Integer.MAX_VALUE;
        record.setStoreId(maxValue);
        assertEquals(maxValue, record.getStoreId());
    }

    @Test
    public void testSetOrderQuantity_MinValue() {
        int minValue = Integer.MIN_VALUE;
        record.setOrderQuantity(minValue);
        assertEquals(minValue, record.getOrderQuantity());
    }

    @Test
    public void testSetOrderQuantity_MaxValue() {
        int maxValue = Integer.MAX_VALUE;
        record.setOrderQuantity(maxValue);
        assertEquals(maxValue, record.getOrderQuantity());
    }

    // Test exceptions

    @Test
    public void testSetProductId_EmptyString() {
        assertThrows(IllegalArgumentException.class, () -> record.setProductId(""));
    }

    @Test
    public void testSetStoreId_NaN() {
        assertThrows(IllegalArgumentException.class, () -> record.setStoreId(Float.NaN));
    }

    @Test
    public void testSetOrderQuantity_NaN() {
        assertThrows(IllegalArgumentException.class, () -> record.setOrderQuantity(Float.NaN));
    }
}