package com.promptora.invsys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class SLSTRNFWTest {

    private SLSTRNFW slstrnfw;

    @BeforeEach
    public void setup() {
        slstrnfw = new SLSTRNFW();
    }

    @AfterEach
    public void teardown() {
        slstrnfw = null;
    }

    // Test case: Normal product ID set and get
    @Test
    public void testSetAndGetProductID_Normal() {
        String productId = "ABC123";
        slstrnfw.setProductID(productId);
        assertEquals(productId, slstrnfw.getProductID());
    }

    // Test case: Edge product ID set (null)
    @Test
    public void testSetAndGetProductID_Null() {
        slstrnfw.setProductID(null);
        assertEquals(null, slstrnfw.getProductID());
    }

    // Test case: Normal quantity sold set and get
    @ParameterizedTest
    @ValueSource(ints = {1, 10, 100})
    public void testSetAndGetQuantitySold_Normal(int quantitySold) {
        slstrnfw.setQuantitySold(quantitySold);
        assertEquals(quantitySold, slstrnfw.getQuantitySold());
    }

    // Test case: Edge quantity sold set (0)
    @Test
    public void testSetAndGetQuantitySold_Zero() {
        slstrnfw.setQuantitySold(0);
        assertEquals(0, slstrnfw.getQuantitySold());
    }

    // Test case: Normal sale price set and get
    @ParameterizedTest
    @ValueSource(doubles = {10.99, 20.99, 30.99})
    public void testSetAndGetSalePrice_Normal(double salePrice) {
        slstrnfw.setSalePrice(salePrice);
        assertEquals(salePrice, slstrnfw.getSalePrice(), 0.01); // Use delta for floating-point comparison
    }

    // Test case: Edge sale price set (0)
    @Test
    public void testSetAndGetSalePrice_Zero() {
        slstrnfw.setSalePrice(0);
        assertEquals(0, slstrnfw.getSalePrice(), 0.01); // Use delta for floating-point comparison
    }

    // Test case: Normal sale date set and get
    @Test
    public void testSetAndGetSaleDate_Normal() {
        String saleDate = "2022-07-25";
        slstrnfw.setSaleDate(saleDate);
        assertEquals(saleDate, slstrnfw.getSaleDate());
    }

    // Test case: Edge sale date set (null)
    @Test
    public void testSetAndGetSaleDate_Null() {
        slstrnfw.setSaleDate(null);
        assertEquals(null, slstrnfw.getSaleDate());
    }

    // Test case: Normal store ID set and get
    @Test
    public void testSetAndGetStoreID_Normal() {
        String storeId = "STORE001";
        slstrnfw.setStoreID(storeId);
        assertEquals(storeId, slstrnfw.getStoreID());
    }

    // Test case: Edge store ID set (null)
    @Test
    public void testSetAndGetStoreID_Null() {
        slstrnfw.setStoreID(null);
        assertEquals(null, slstrnfw.getStoreID());
    }

    // Test case: Exception thrown when setting negative quantity sold
    @Test
    public void testSetQuantitySold_Negative() {
        assertThrows(IllegalArgumentException.class, () -> slstrnfw.setQuantitySold(-1));
    }

    // Test case: Exception thrown when setting negative sale price
    @Test
    public void testSetSalePrice_Negative() {
        assertThrows(IllegalArgumentException.class, () -> slstrnfw.setSalePrice(-10.99));
    }
}