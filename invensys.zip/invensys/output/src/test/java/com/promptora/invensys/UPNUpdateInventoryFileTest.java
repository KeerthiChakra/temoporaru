package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ArgumentsSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

public class UPNUpdateInventoryFileTest {

    private UPNUpdateInventoryFile updateInventoryFile;
    private UPNInventoryRecord inventoryRecord;
    private UPNInventoryFile inventoryFile;

    @BeforeEach
    public void setup() {
        inventoryRecord = mock(UPNInventoryRecord.class);
        inventoryFile = mock(UPNInventoryFile.class);
        when(inventoryRecord.getInventoryFile()).thenReturn(inventoryFile);

        updateInventoryFile = new UPNUpdateInventoryFile();
        updateInventoryFile.setInventoryRecord(inventoryRecord);
    }

    @Test
    public void testUpdateInventoryFile_NormalCase() {
        // Given
        int initialQuantityInStock = 100;
        when(inventoryFile.getQuantityInStock()).thenReturn(initialQuantityInStock);
        int quantitySold = 20;

        // When
        updateInventoryFile.updateInventoryFile(quantitySold);

        // Then
        verify(inventoryFile).setQuantityInStock(initialQuantityInStock - quantitySold);
    }

    @ParameterizedTest
    @ArgumentsSource(TestData.class)
    public void testUpdateInventoryFile_Parameterized(int initialQuantityInStock, int quantitySold) {
        // Given
        when(inventoryFile.getQuantityInStock()).thenReturn(initialQuantityInStock);

        // When
        updateInventoryFile.updateInventoryFile(quantitySold);

        // Then
        verify(inventoryFile).setQuantityInStock(initialQuantityInStock - quantitySold);
    }

    public static class TestData implements ArgumentsProvider {
        @Override
        public Stream<? extends Arguments> provideArguments(ExtensionContext context) {
            return Stream.of(
                arguments(100, 20),
                arguments(50, 10),
                arguments(200, 0)
            );
        }
    }

    @Test
    public void testUpdateInventoryFile_QuantitySoldExceedsStock() {
        // Given
        int initialQuantityInStock = 100;
        when(inventoryFile.getQuantityInStock()).thenReturn(initialQuantityInStock);
        int quantitySold = 150;

        // Then
        assertThrows(IllegalArgumentException.class, () -> updateInventoryFile.updateInventoryFile(quantitySold));
    }

    @Test
    public void testUpdateInventoryFile_NullQuantitySold() {
        // Given
        Integer quantitySold = null;

        // Then
        assertThrows(NullPointerException.class, () -> updateInventoryFile.updateInventoryFile(quantitySold));
    }
}