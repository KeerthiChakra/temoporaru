package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class SuppliersTableTest {

    private SuppliersTable suppliersTable;

    @BeforeEach
    public void setup() {
        suppliersTable = new SuppliersTable();
    }

    // Test getters and setters for normal cases

    @Test
    public void testGetAndSetSupplierId_NormalCase() {
        String expectedSupplierId = "12345";
        suppliersTable.setSupplierId(expectedSupplierId);
        assertEquals(expectedSupplierId, suppliersTable.getSupplierId());
    }

    @Test
    public void testGetAndSetSupplierName_NormalCase() {
        String expectedSupplierName = "John Doe Inc.";
        suppliersTable.setSupplierName(expectedSupplierName);
        assertEquals(expectedSupplierName, suppliersTable.getSupplierName());
    }

    // Test getters and setters for edge cases

    @ParameterizedTest
    @CsvSource({
            "0",
            "-1"
    })
    public void testGetAndSetSupplierId_EmptyOrNegativeLength(int length) {
        String supplierId = newString(length);
        suppliersTable.setSupplierId(supplierId);
        assertEquals(supplierId, suppliersTable.getSupplierId());
    }

    @ParameterizedTest
    @CsvSource({
            "256"
    })
    public void testGetAndSetSupplierName_TooLong(int length) {
        String supplierName = newString(length);
        assertThrows(StringIndexOutOfBoundsException.class, () -> suppliersTable.setSupplierName(supplierName));
    }

    // Test for max length of supplierId

    @ParameterizedTest
    @CsvSource({
            "123456"
    })
    public void testSetSupplierId_TooLong(String supplierId) {
        assertThrows(StringIndexOutOfBoundsException.class, () -> suppliersTable.setSupplierId(supplierId));
    }

    // Test for max length of supplierName

    @ParameterizedTest
    @CsvSource({
            "John Doe Inc. This is a very long name"
    })
    public void testSetSupplierName_TooLong(String supplierName) {
        assertThrows(StringIndexOutOfBoundsException.class, () -> suppliersTable.setSupplierName(supplierName));
    }

    // Test for null values

    @Test
    public void testGetAndSetSupplierId_Null() {
        suppliersTable.setSupplierId(null);
        assertEquals("", suppliersTable.getSupplierId());
    }

    private String newString(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append('a');
        }
        return sb.toString();
    }
}