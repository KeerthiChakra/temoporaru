package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DLYRECTest {

    private DLYREC dlyrec;

    @BeforeEach
    public void setup() {
        dlyrec = new DLYREC();
    }

    // Normal cases

    @Test
    public void testDefaultConstructor() {
        assertTrue(dlyrec.getRecordType() == null);
        assertTrue(dlyrec.getRecordData() == null);
    }

    @ParameterizedTest
    @MethodSource("recordTypeProvider")
    public void testSetRecordType(String recordType) {
        dlyrec.setRecordType(recordType);
        assertEquals(recordType, dlyrec.getRecordType());
    }

    private static Stream<Arguments> recordTypeProvider() {
        return Stream.of(
                Arguments.of("A"),
                Arguments.of("B"),
                Arguments.of("")
        );
    }

    @ParameterizedTest
    @MethodSource("recordDataProvider")
    public void testSetRecordData(String recordData) {
        dlyrec.setRecordData(recordData);
        assertEquals(recordData, dlyrec.getRecordData());
    }

    private static Stream<Arguments> recordDataProvider() {
        return Stream.of(
                Arguments.of("Some data"),
                Arguments.of("More data with length less than 200"),
                Arguments.of("")
        );
    }

    @Test
    public void testToString() {
        dlyrec.setRecordType("A");
        dlyrec.setRecordData("Some data");
        assertEquals("DLYREC{recordType='A', recordData='Some data'}", dlyrec.toString());
    }

    // Edge cases

    @ParameterizedTest
    @MethodSource("longRecordTypeProvider")
    public void testLongRecordType(String recordType) {
        assertThrows(IllegalArgumentException.class, () -> dlyrec.setRecordType(recordType));
    }

    private static Stream<Arguments> longRecordTypeProvider() {
        return Stream.of(
                Arguments.of(new String(new char[DLYREC.RECORD_TYPE_SIZE + 1]).replace('\0', 'A'))
        );
    }

    @ParameterizedTest
    @MethodSource("longRecordDataProvider")
    public void testLongRecordData(String recordData) {
        assertThrows(IllegalArgumentException.class, () -> dlyrec.setRecordData(recordData));
    }

    private static Stream<Arguments> longRecordDataProvider() {
        return Stream.of(
                Arguments.of(new String(new char[DLYREC.RECORD_DATA_SIZE + 1]).replace('\0', 'A'))
        );
    }
}