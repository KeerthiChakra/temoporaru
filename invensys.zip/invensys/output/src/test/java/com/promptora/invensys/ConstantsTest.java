package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class ConstantsTest {

    @BeforeEach
    public void setUp() {
        // No setup needed for this test suite
    }

    @ParameterizedTest
    @CsvSource({
            "PRODUCT_NAME_MAX_LENGTH, 50",
            "QUANTITY_SOLD_MAX_VALUE, 9999",
            "SALE_PRICE_MAX_VALUE, 999999.99",
            "STORE_ID_MAX_VALUE, 9999"
    })
    public void testConstantValues(String constantName, double expectedValue) {
        // Get the constant field using reflection
        java.lang.reflect.Field field = java.lang.reflect.Array.get(Constants.class.getDeclaredFields(), 0);
        Object constantValue = null;
        try {
            field.setAccessible(true);
            constantValue = field.get(null);
        } catch (IllegalAccessException e) {
            assert false : "Failed to get constant value";
        }

        // Assert the expected value
        assertEquals(expectedValue, constantValue, "Constant value mismatch for " + constantName);
    }

    @ParameterizedTest
    @CsvSource({
            "PRODUCT_NAME_MAX_LENGTH, 51", // exceeded max length
            "QUANTITY_SOLD_MAX_VALUE, 10000", // exceeded max value
            "SALE_PRICE_MAX_VALUE, 999999.991", // exceeded max value
            "STORE_ID_MAX_VALUE, 10000" // exceeded max value
    })
    public void testConstantValueBoundaries(String constantName, double invalidValue) {
        // Attempt to set the constant field using reflection
        java.lang.reflect.Field field = null;
        try {
            field = Constants.class.getDeclaredField(constantName);
            field.setAccessible(true);
            field.set(null, invalidValue); // This should not succeed
            assert false : "Expected IllegalAccessException for setting constant value";
        } catch (NoSuchFieldException e) {
            assert false : "Failed to get constant field";
        } catch (IllegalAccessException e) {
            // Expected exception
        }
    }

    @Test
    public void testConstantImmutability() {
        // Attempt to modify a constant field using reflection
        java.lang.reflect.Field field = null;
        try {
            field = Constants.class.getDeclaredField("PRODUCT_NAME_MAX_LENGTH");
            field.setAccessible(true);
            field.set(null, 100); // This should not succeed
            assert false : "Expected IllegalAccessException for setting constant value";
        } catch (NoSuchFieldException e) {
            assert false : "Failed to get constant field";
        } catch (IllegalAccessException e) {
            // Expected exception
        }
    }

    @Test
    public void testConstantFieldsAreFinal() {
        java.lang.reflect.Field[] fields = Constants.class.getDeclaredFields();
        for (java.lang.reflect.Field field : fields) {
            assert java.lang.reflect.Modifier.isFinal(field.getModifiers()) : "Constant field is not final";
        }
    }
}