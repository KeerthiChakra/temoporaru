package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class InventoryFileTest {

    private InventoryFile inventoryFile;
    private InventoryRecord record1;
    private InventoryRecord record2;

    @BeforeEach
    void setup() {
        inventoryFile = new InventoryFile();
        record1 = new InventoryRecord("record-1", "desc-1");
        record2 = new InventoryRecord("record-2", "desc-2");
    }

    @Test
    public void testConstructor() {
        assertNotNull(inventoryFile.getRecords());
        assertTrue(inventoryFile.getRecords().isEmpty());
    }

    @Test
    public void testAddRecord() {
        inventoryFile.addRecord(record1);
        assertEquals(1, inventoryFile.getRecords().size());
        assertSame(record1, inventoryFile.getRecords().get(0));
    }

    @ParameterizedTest
    @MethodSource("provideMultipleRecords")
    public void testAddMultipleRecords(InventoryRecord... records) {
        for (InventoryRecord record : records) {
            inventoryFile.addRecord(record);
        }
        assertEquals(records.length, inventoryFile.getRecords().size());
        assertArrayEquals(records, inventoryFile.getRecords().toArray());
    }

    private static InventoryRecord[][] provideMultipleRecords() {
        return new InventoryRecord[][]{
                {record1},
                {record1, record2},
                {record1, record2, new InventoryRecord("record-3", "desc-3")}
        };
    }

    @Test
    public void testGetRecords() {
        inventoryFile.addRecord(record1);
        ArrayList<InventoryRecord> records = inventoryFile.getRecords();
        assertEquals(1, records.size());
        assertSame(record1, records.get(0));
    }

    @Test
    public void testAddNullRecord() {
        assertThrows(NullPointerException.class, () -> inventoryFile.addRecord(null));
    }

    @Test
    public void testGetRecordsModification() {
        inventoryFile.addRecord(record1);
        ArrayList<InventoryRecord> records = inventoryFile.getRecords();
        records.clear(); // modifying the returned list should not affect the internal state
        assertEquals(1, inventoryFile.getRecords().size());
    }
}

public class InventoryRecord {
    private String id;
    private String description;

    public InventoryRecord(String id, String description) {
        this.id = id;
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InventoryRecord)) return false;

        InventoryRecord that = (InventoryRecord) o;

        if (!getId().equals(that.getId())) return false;
        return getDescription().equals(that.getDescription());
    }

    @Override
    public int hashCode() {
        int result = getId().hashCode();
        result = 31 * result + getDescription().hashCode();
        return result;
    }

    // Getters and setters for id and description...
}