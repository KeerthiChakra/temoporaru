package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class SalesTransactionsTableTest {

    private SalesTransactionsTable salesTransactionsTable;

    @BeforeEach
    public void setUp() {
        salesTransactionsTable = new SalesTransactionsTable();
    }

    // Test default constructor values
    @ParameterizedTest
    @ValueSource(strings = {"", "12345"})
    public void testDefaultConstructorValues(String expectedSalesTransactionId) {
        assertEquals(expectedSalesTransactionId, salesTransactionsTable.getSalesTransactionId());
        assertEquals(0.0, salesTransactionsTable.getAmount(), 1e-6);
        assert (salesTransactionsTable.getTransactionDate() == null);
    }

    // Test setter and getter for salesTransactionId
    @ParameterizedTest
    @ValueSource(strings = {"12345", "67890"})
    public void testSetAndGetSalesTransactionId(String salesTransactionId) {
        salesTransactionsTable.setSalesTransactionId(salesTransactionId);
        assertEquals(salesTransactionId, salesTransactionsTable.getSalesTransactionId());
    }

    // Test setter and getter for amount
    @ParameterizedTest
    @ValueSource(doubles = {10.99, 20.0})
    public void testSetAndGetAmount(double amount) {
        salesTransactionsTable.setAmount(amount);
        assertEquals(amount, salesTransactionsTable.getAmount(), 1e-6);
    }

    // Test setter and getter for transactionDate
    @ParameterizedTest
    @ValueSource(dates = {new Date(1643723400), new Date(1646315200)})
    public void testSetAndGetTransactionDate(Date transactionDate) {
        salesTransactionsTable.setTransactionDate(transactionDate);
        assertEquals(transactionDate, salesTransactionsTable.getTransactionDate());
    }

    // Test exception for invalid salesTransactionId length
    @ParameterizedTest
    @ValueSource(strings = {"1234", "123456"})
    public void testInvalidSalesTransactionIdLength(String salesTransactionId) {
        assertThrows(IllegalArgumentException.class, () -> salesTransactionsTable.setSalesTransactionId(salesTransactionId));
    }

    // Test edge case for minimum and maximum amount values
    @ParameterizedTest
    @ValueSource(doubles = {Double.MIN_VALUE, Double.MAX_VALUE})
    public void testEdgeCaseAmount(double amount) {
        assertThrows(IllegalArgumentException.class, () -> salesTransactionsTable.setAmount(amount));
    }
}