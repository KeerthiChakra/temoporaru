package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class INVMNUWSTest {

    private INVMNUWS menuOptionInstance;

    @BeforeEach
    public void setup() {
        menuOptionInstance = new INVMNUWS();
    }

    // Normal cases

    @Test
    public void testDefaultConstructor() {
        assertEquals("", menuOptionInstance.getMenuOption());
    }

    @ParameterizedTest
    @ValueSource(strings = {"abc", "def", "ghi"})
    public void testSetAndGetMenuOption(String menuOption) {
        menuOptionInstance.setMenuOption(menuOption);
        assertEquals(menuOption.substring(0, Math.min(menuOption.length(), INVMNUWS.MENU_OPTION_SIZE)), menuOptionInstance.getMenuOption());
    }

    // Edge cases

    @Test
    public void testSetMenuOptionWithEmptyString() {
        menuOptionInstance.setMenuOption("");
        assertEquals("", menuOptionInstance.getMenuOption());
    }

    @Test
    public void testSetMenuOptionWithNull() {
        assertThrows(NullPointerException.class, () -> menuOptionInstance.setMenuOption(null));
    }

    @Test
    public void testSetMenuOptionWithLongString() {
        String longString = "abcdefghijklmnopqrstuvwxyz";
        menuOptionInstance.setMenuOption(longString);
        assertEquals("a", menuOptionInstance.getMenuOption());
    }

    // Exception cases

    @Test
    public void testSetMenuOptionWithNullInConstructor() {
        assertThrows(NullPointerException.class, () -> new INVMNUWS().setMenuOption(null));
    }
}