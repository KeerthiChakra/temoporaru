package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class SLTRNRECTest {

    private SLTRNREC sltrnrec;

    @BeforeEach
    public void setup() {
        sltrnrec = new SLTRNREC();
    }

    // Test transaction ID normal case
    @ParameterizedTest
    @MethodSource("validTransactionIds")
    public void testSetGetTransactionId(String transactionId) {
        sltrnrec.setTransactionId(transactionId);
        assertEquals(transactionId, sltrnrec.getTransactionId());
    }

    private static Arguments[] validTransactionIds() {
        return new Arguments[]{
                Arguments.of("1234567890"),
                Arguments.of("abcdefghij")
        };
    }

    // Test transaction ID edge case: null
    @Test
    public void testSetTransactionIdNull() {
        assertThrows(IllegalArgumentException.class, () -> sltrnrec.setTransactionId(null));
    }

    // Test transaction ID edge case: too long
    @Test
    public void testSetTransactionIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> sltrnrec.setTransactionId("123456789012"));
    }

    // Test product ID normal case
    @ParameterizedTest
    @MethodSource("validProductIds")
    public void testSetGetProductId(String productId) {
        sltrnrec.setProductId(productId);
        assertEquals(productId, sltrnrec.getProductId());
    }

    private static Arguments[] validProductIds() {
        return new Arguments[]{
                Arguments.of("1234567890"),
                Arguments.of("abcdefghij")
        };
    }

    // Test product ID edge case: null
    @Test
    public void testSetProductIdNull() {
        assertThrows(IllegalArgumentException.class, () -> sltrnrec.setProductId(null));
    }

    // Test product ID edge case: too long
    @Test
    public void testSetProductIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> sltrnrec.setProductId("123456789012"));
    }

    // Test sale quantity normal case
    @ParameterizedTest
    @MethodSource("validSaleQuantities")
    public void testSetGetSaleQuantity(int saleQuantity) {
        sltrnrec.setSaleQuantity(saleQuantity);
        assertEquals(saleQuantity, sltrnrec.getSaleQuantity());
    }

    private static Arguments[] validSaleQuantities() {
        return new Arguments[]{
                Arguments.of(0),
                Arguments.of(99999)
        };
    }

    // Test sale quantity edge case: negative
    @Test
    public void testSetSaleQuantityNegative() {
        assertThrows(IllegalArgumentException.class, () -> sltrnrec.setSaleQuantity(-1));
    }

    // Test sale quantity edge case: too long
    @Test
    public void testSetSaleQuantityTooLong() {
        assertThrows(IllegalArgumentException.class, () -> sltrnrec.setSaleQuantity(1000000));
    }

    // Test sale total normal case
    @ParameterizedTest
    @MethodSource("validSaleTotals")
    public void testSetGetSaleTotal(BigDecimal saleTotal) {
        sltrnrec.setSaleTotal(saleTotal);
        assertEquals(saleTotal, sltrnrec.getSaleTotal());
    }

    private static Arguments[] validSaleTotals() {
        return new Arguments[]{
                Arguments.of(new BigDecimal("0.00")),
                Arguments.of(new BigDecimal("99999.99"))
        };
    }

    // Test sale total edge case: null
    @Test
    public void testSetSaleTotalNull() {
        assertThrows(IllegalArgumentException.class, () -> sltrnrec.setSaleTotal(null));
    }

    // Test sale total edge case: too long
    @Test
    public void testSetSaleTotalTooLong() {
        assertThrows(IllegalArgumentException.class, () -> sltrnrec.setSaleTotal(new BigDecimal("1000000.00")));
    }
}