package com.promptora.invsys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class InventoryFileReaderTest {

    private static final String TEST_FILE_NAME = "inventory-test.txt";
    private File testFile;

    @BeforeEach
    void setup() throws IOException {
        testFile = new File(TEST_FILE_NAME);
        testFile.createNewFile();
    }

    @AfterEach
    void tearDown() {
        if (testFile.exists()) {
            testFile.delete();
        }
    }

    @Test
    void readInventoryRecords_EmptyFile_ReturnsEmptyArray() throws IOException {
        InventoryFileReader reader = new InventoryFileReader();
        InventoryRecord[] records = reader.readInventoryRecords();

        assertArrayEquals(new InventoryRecord[0], records);
    }

    @ParameterizedTest
    @ValueSource(strings = {"item1,description1,10.99,5", "item2,description2,9.99,3"})
    void readInventoryRecords_SingleRecord(String record) throws IOException {
        try (FileWriter writer = new FileWriter(testFile)) {
            writer.write(record);
        }

        InventoryFileReader reader = new InventoryFileReader();
        InventoryRecord[] records = reader.readInventoryRecords();

        assertEquals(1, records.length);

        InventoryRecord expected = new InventoryRecord(
                record.split(",")[0],
                record.split(",")[1],
                Double.parseDouble(record.split(",")[2]),
                Integer.parseInt(record.split(",")[3])
        );
        assertEquals(expected, records[0]);
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "item1,description1,10.99,5\n" +
                    "item2,description2,9.99,3",
            "item1,description1,10.99,5\n" +
                    "item2,description2,9.99,3\n" +
                    "item3,description3,8.99,4"
    })
    void readInventoryRecords_MultipleRecords(String records) throws IOException {
        try (FileWriter writer = new FileWriter(testFile)) {
            writer.write(records);
        }

        InventoryFileReader reader = new InventoryFileReader();
        InventoryRecord[] actual = reader.readInventoryRecords();

        String[] recordStrings = records.split("\n");
        assertEquals(recordStrings.length, actual.length);

        for (int i = 0; i < recordStrings.length; i++) {
            String[] fields = recordStrings[i].split(",");
            InventoryRecord expected = new InventoryRecord(
                    fields[0],
                    fields[1],
                    Double.parseDouble(fields[2]),
                    Integer.parseInt(fields[3])
            );
            assertEquals(expected, actual[i]);
        }
    }

    @Test
    void readInventoryRecords_FileDoesNotExist_ReturnsEmptyArray() {
        testFile.delete();
        InventoryFileReader reader = new InventoryFileReader();
        InventoryRecord[] records = reader.readInventoryRecords();

        assertArrayEquals(new InventoryRecord[0], records);
    }

    @Test
    void readInventoryRecords_IOException_PrintsErrorAndReturnsEmptyArray() throws IOException {
        // Make the file unreadable
        testFile.setReadable(false);

        InventoryFileReader reader = new InventoryFileReader();
        InventoryRecord[] records = reader.readInventoryRecords();

        assertArrayEquals(new InventoryRecord[0], records);
    }
}