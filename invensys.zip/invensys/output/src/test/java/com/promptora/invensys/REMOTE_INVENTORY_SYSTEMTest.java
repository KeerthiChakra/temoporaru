package com.promptora.invsys;

public class InventorySystem {
    private Map<String, Integer> inventory = new HashMap<>();

    public void addItem(String itemName, int quantity) {
        if (inventory.containsKey(itemName)) {
            inventory.put(itemName, inventory.get(itemName) + quantity);
        } else {
            inventory.put(itemName, quantity);
        }
    }

    public void removeItem(String itemName, int quantity) throws Exception {
        if (!inventory.containsKey(itemName)) {
            throw new Exception("Item not found in the inventory");
        }
        if (inventory.get(itemName) < quantity) {
            throw new Exception("Not enough items to remove");
        }
        inventory.put(itemName, inventory.get(itemName) - quantity);
    }

    public boolean exists(String itemName) {
        return inventory.containsKey(itemName);
    }

    public void run() {
        // This method's implementation is not provided, so it's hard to test directly.
        // For demonstration purposes, let's assume it uses the above methods internally.
    }
}

import org.junit.jupiter.api.*;
import java.util.HashMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

public class RemoteInventorySystemTest {

    private InventorySystem inventorySystem;

    @BeforeEach
    void setUp() {
        inventorySystem = new InventorySystem();
    }

    @AfterEach
    void tearDown() {
        // Any cleanup if needed, but in this context, none is required.
    }

    @ParameterizedTest
    @DisplayName("Adding items to the inventory")
    @CsvSource({
            "ItemA, 10",
            "ItemB, 20",
            "ItemC, 30"
    })
    void testAddItem(String itemName, int quantity) {
        // Arrange and Act
        inventorySystem.addItem(itemName, quantity);

        // Assert
        assertTrue(inventorySystem.exists(itemName));
        assertEquals(quantity, inventorySystem.inventory.get(itemName)); // Note: This is for demonstration; ideally, we shouldn't access internal state directly.
    }

    @ParameterizedTest
    @DisplayName("Removing items from the inventory")
    @CsvSource({
            "ItemA, 5",
            "ItemB, 10",
            "ItemC, 15"
    })
    void testRemoveItem(String itemName, int quantity) throws Exception {
        // Arrange: Add item first to be able to remove it
        inventorySystem.addItem(itemName, 20);
        
        // Act and Assert
        assertDoesNotThrow(() -> inventorySystem.removeItem(itemName, quantity));
        assertEquals(15, inventorySystem.inventory.get(itemName)); // Note: Same as above.
    }

    @Test
    @DisplayName("Attempting to remove more items than exist")
    void testRemoveMoreItemsThanExist() throws Exception {
        // Arrange: Add item first to be able to remove it
        inventorySystem.addItem("ItemA", 20);
        
        // Act and Assert
        assertThrows(Exception.class, () -> inventorySystem.removeItem("ItemA", 25));
    }

    @Test
    @DisplayName("Attempting to remove an item that doesn't exist")
    void testRemoveNonExistentItem() throws Exception {
        // Act and Assert
        assertThrows(Exception.class, () -> inventorySystem.removeItem("ItemD", 5));
    }

    @ParameterizedTest
    @DisplayName("Checking if items exist in the inventory")
    @CsvSource({
            "true, ItemA",
            "false, ItemE"
    })
    void testExists(boolean expectedResult, String itemName) {
        // Arrange: Add item first to be able to check its existence
        if (expectedResult) {
            inventorySystem.addItem(itemName, 10);
        }
        
        // Act and Assert
        assertEquals(expectedResult, inventorySystem.exists(itemName));
    }

    @Test
    @DisplayName("Running the inventory system")
    void testRun() {
        // Arrange, Act, and Assert: Without the implementation of run(), we can't assert much.
        // Ideally, you'd have specific assertions based on what run() is supposed to do internally.
        assertDoesNotThrow(inventorySystem::run);
    }
}