package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductReportRecordTest {

    private ProductReportRecord record;

    @BeforeEach
    void setup() {
        record = new ProductReportRecord();
    }

    // Normal case tests

    @Test
    void testGetProductId_NormalCase() {
        String productId = "12345";
        record.setProductId(productId);
        assertEquals(productId, record.getProductId());
    }

    @Test
    void testGetProductName_NormalCase() {
        String productName = "Product Name";
        record.setProductName(productName);
        assertEquals(productName, record.getProductName());
    }

    @Test
    void testGetSaleDate_NormalCase() {
        String saleDate = "20220101";
        record.setSaleDate(saleDate);
        assertEquals(saleDate, record.getSaleDate());
    }

    @Test
    void testGetSaleAmount_NormalCase() {
        BigDecimal saleAmount = new BigDecimal("123.45");
        record.setSaleAmount(saleAmount);
        assertEquals(saleAmount, record.getSaleAmount());
    }

    // Edge case tests

    @Test
    void testSetProductId_EmptyString() {
        assertThrows(IllegalArgumentException.class, () -> record.setProductId(""));
    }

    @Test
    void testSetProductName_EmptyString() {
        assertThrows(IllegalArgumentException.class, () -> record.setProductName(""));
    }

    @Test
    void testSetSaleDate_EmptyString() {
        assertThrows(IllegalArgumentException.class, () -> record.setSaleDate(""));
    }

    @Test
    void testSetSaleAmount_Null() {
        assertThrows(NullPointerException.class, () -> record.setSaleAmount(null));
    }

    // Exception tests

    @ParameterizedTest(name = "Product ID must be {0} characters or less")
    @ValueSource(strings = {"123456", "1234567"})
    void testSetProductId_TooLong(String productId) {
        assertThrows(IllegalArgumentException.class, () -> record.setProductId(productId));
    }

    @ParameterizedTest(name = "Product name must be {0} characters or less")
    @ValueSource(strings = {"Product Name Too Long", "Product Name Too Long Again"})
    void testSetProductName_TooLong(String productName) {
        assertThrows(IllegalArgumentException.class, () -> record.setProductName(productName));
    }

    @ParameterizedTest(name = "Sale date must be {0} characters or less")
    @ValueSource(strings = {"202201012", "202201013"})
    void testSetSaleDate_TooLong(String saleDate) {
        assertThrows(IllegalArgumentException.class, () -> record.setSaleDate(saleDate));
    }

    @ParameterizedTest(name = "Sale amount must have {0} or fewer decimal places")
    @ValueSource(strings = {"123.456", "123.457"})
    void testSetSaleAmount_TooManyDecimalPlaces(String saleAmount) {
        BigDecimal bigDecimal = new BigDecimal(saleAmount);
        assertThrows(IllegalArgumentException.class, () -> record.setSaleAmount(bigDecimal));
    }
}