package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class SalesTransactionProcessorTest {

    private SalesTransactionFileReader salesTransactionFileReaderMock;
    private SalesTransactionFileWriter salesTransactionFileWriterMock;
    private SalesTransactionProcessor salesTransactionProcessor;

    @BeforeEach
    void setup() {
        salesTransactionFileReaderMock = mock(SalesTransactionFileReader.class);
        salesTransactionFileWriterMock = mock(SalesTransactionFileWriter.class);
        salesTransactionProcessor = new SalesTransactionProcessor(salesTransactionFileReaderMock, salesTransactionFileWriterMock);
    }

    @Test
    public void testProcessSalesTransactions_HappyPath() {
        // Arrange
        SalesTransaction[] expectedSalesTransactions = new SalesTransaction[]{new SalesTransaction(1), new SalesTransaction(2)};
        when(salesTransactionFileReaderMock.readSalesTransactions()).thenReturn(expectedSalesTransactions);

        // Act
        salesTransactionProcessor.processSalesTransactions();

        // Assert
        verify(salesTransactionFileWriterMock).writeSalesTransactions(expectedSalesTransactions);
    }

    @Test
    public void testProcessSalesTransactions_NoTransactions() {
        // Arrange
        SalesTransaction[] expectedSalesTransactions = new SalesTransaction[0];
        when(salesTransactionFileReaderMock.readSalesTransactions()).thenReturn(expectedSalesTransactions);

        // Act
        salesTransactionProcessor.processSalesTransactions();

        // Assert
        verify(salesTransactionFileWriterMock, never()).writeSalesTransactions(any());
    }

    @Test
    public void testProcessSalesTransactions_IOException() {
        // Arrange
        when(salesTransactionFileReaderMock.readSalesTransactions()).thenThrow(new IOException("Mocked IO Exception"));

        // Act and Assert
        assertThrows(IOException.class, () -> salesTransactionProcessor.processSalesTransactions());
    }

    @ParameterizedTest
    @CsvSource({
            "1, 2",
            "3, 4",
            "5, 6"
    })
    public void testProcessSalesTransactions_MultipleTransactions(int transactionId1, int transactionId2) {
        // Arrange
        SalesTransaction[] expectedSalesTransactions = new SalesTransaction[]{new SalesTransaction(transactionId1), new SalesTransaction(transactionId2)};
        when(salesTransactionFileReaderMock.readSalesTransactions()).thenReturn(expectedSalesTransactions);

        // Act
        salesTransactionProcessor.processSalesTransactions();

        // Assert
        verify(salesTransactionFileWriterMock).writeSalesTransactions(expectedSalesTransactions);
    }

    @Test
    public void testProcessSalesTransactions_NullTransactions() {
        // Arrange
        when(salesTransactionFileReaderMock.readSalesTransactions()).thenReturn(null);

        // Act and Assert
        assertThrows(NullPointerException.class, () -> salesTransactionProcessor.processSalesTransactions());
    }
}

class SalesTransaction {
    private int transactionId;

    public SalesTransaction(int transactionId) {
        this.transactionId = transactionId;
    }

    public int getTransactionId() {
        return transactionId;
    }
}