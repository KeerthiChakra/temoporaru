package com.promptora.invsys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StoreReportRecordTest {

    private StoreReportRecord record;

    @BeforeEach
    public void setUp() {
        record = new StoreReportRecord();
    }

    @AfterEach
    public void tearDown() {
        record = null;
    }

    // Test getters and setters for storeId

    @Test
    public void testGetStoreId_DefaultValue() {
        assertEquals(0, record.getStoreId());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 10, 100})
    public void testSetAndGetStoreId_NormalCases(int storeId) {
        record.setStoreId(storeId);
        assertEquals(storeId, record.getStoreId());
    }

    @Test
    public void testSetStoreId_NegativeNumber() {
        int negativeStoreId = -1;
        assertThrows(IllegalArgumentException.class, () -> record.setStoreId(negativeStoreId));
    }

    // Test getters and setters for storeName

    @Test
    public void testGetStoreName_DefaultValue() {
        assertEquals("", record.getStoreName());
    }

    @ParameterizedTest
    @ValueSource(strings = {"store1", "Another Store"})
    public void testSetAndGetStoreName_NormalCases(String storeName) {
        record.setStoreName(storeName);
        assertEquals(storeName, record.getStoreName());
    }

    @Test
    public void testSetStoreName_Null() {
        String nullStoreName = null;
        assertThrows(NullPointerException.class, () -> record.setStoreName(nullStoreName));
    }

    // Test getters and setters for saleDate

    @Test
    public void testGetSaleDate_DefaultValue() {
        assertEquals("", record.getSaleDate());
    }

    @ParameterizedTest
    @ValueSource(strings = {"2022-01-01", "2023-12-31"})
    public void testSetAndGetSaleDate_NormalCases(String saleDate) {
        record.setSaleDate(saleDate);
        assertEquals(saleDate, record.getSaleDate());
    }

    // Test getters and setters for saleAmount

    @Test
    public void testGetSaleAmount_DefaultValue() {
        assertEquals(0.00, record.getSaleAmount(), 0.01);
    }

    @ParameterizedTest
    @ValueSource(doubles = {1.00, 100.50})
    public void testSetAndGetSaleAmount_NormalCases(double saleAmount) {
        record.setSaleAmount(saleAmount);
        assertEquals(saleAmount, record.getSaleAmount(), 0.01);
    }

    // Test constructor

    @Test
    public void testConstructor_DefaultValues() {
        StoreReportRecord newRecord = new StoreReportRecord();
        assertEquals(0, newRecord.getStoreId());
        assertEquals("", newRecord.getStoreName());
        assertEquals("", newRecord.getSaleDate());
        assertEquals(0.00, newRecord.getSaleAmount(), 0.01);
    }
}