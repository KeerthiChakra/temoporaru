package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class SQLOPSTest {

    private SQL_OPS sqlOps;

    @BeforeEach
    void setup() {
        sqlOps = new SQL_OPS();
    }

    @Test
    void testDefaultConstructor() {
        assertEquals("", sqlOps.getSqlStatement());
        assertEquals(0, sqlOps.getSqlCode());
        assertEquals("", sqlOps.getErrorMessage());
    }

    @ParameterizedTest(name = "testSettersAndGetters")
    @MethodSource("provideTestData")
    void testSettersAndGetters(String sqlStatement, int sqlCode, String errorMessage) {
        sqlOps.setSqlStatement(sqlStatement);
        sqlOps.setSqlCode(sqlCode);
        sqlOps.setErrorMessage(errorMessage);

        assertEquals(sqlStatement, sqlOps.getSqlStatement());
        assertEquals(sqlCode, sqlOps.getSqlCode());
        assertEquals(errorMessage, sqlOps.getErrorMessage());
    }

    private static Stream<Arguments> provideTestData() {
        return Stream.of(
                Arguments.of("SELECT * FROM table", 1, "Error message"),
                Arguments.of("", -1, ""),
                Arguments.of(null, Integer.MAX_VALUE, null)
        );
    }

    @Test
    void testSetSqlStatementMaxLength() {
        String longString = new String(new char[MAX_SQL_STATEMENT_LENGTH + 1]).replace("\0", "#");
        assertThrows(IllegalArgumentException.class, () -> sqlOps.setSqlStatement(longString));
    }

    @Test
    void testSetErrorMessageMaxLength() {
        String longString = new String(new char[MAX_ERROR_MESSAGE_LENGTH + 1]).replace("\0", "#");
        assertThrows(IllegalArgumentException.class, () -> sqlOps.setErrorMessage(longString));
    }
}

public void setSqlStatement(String sqlStatement) {
    if (sqlStatement.length() > MAX_SQL_STATEMENT_LENGTH) {
        throw new IllegalArgumentException("SQL statement exceeds maximum allowed length");
    }
    this.sqlStatement = sqlStatement;
}

public void setErrorMessage(String errorMessage) {
    if (errorMessage.length() > MAX_ERROR_MESSAGE_LENGTH) {
        throw new IllegalArgumentException("Error message exceeds maximum allowed length");
    }
    this.errorMessage = errorMessage;
}