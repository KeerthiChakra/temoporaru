package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;

public class MQPMOTest {

    private MQPMO mqpmo;

    @BeforeEach
    public void setup() {
        this.mqpmo = new MQPMO();
    }

    /**
     * Test default values of MQPMO object after construction.
     */
    @Test
    public void testDefaultValues() {
        assertEquals(MQPMO.VERSION_DEFAULT, mqpmo.getVersion());
        assertEquals(0L, mqpmo.getOptions());
    }

    /**
     * Test setting and getting version with valid values.
     *
     * @param version - Version to be set.
     */
    @ParameterizedTest
    @ValueSource(ints = {1, 2, 10})
    public void testSetAndGetVersionWithValidValues(int version) {
        mqpmo.setVersion(version);
        assertEquals(version, mqpmo.getVersion());
    }

    /**
     * Test setting and getting options with valid values.
     *
     * @param options - Options to be set.
     */
    @ParameterizedTest
    @ValueSource(longs = {0L, 1L, 10L})
    public void testSetAndGetOptionsWithValidValues(long options) {
        mqpmo.setOptions(options);
        assertEquals(options, mqpmo.getOptions());
    }

    /**
     * Test setting version with invalid (negative) values.
     *
     * @param version - Version to be set.
     */
    @ParameterizedTest
    @ValueSource(ints = {-1, -10})
    public void testSetVersionWithInvalidValues(int version) {
        assertThrows(IllegalArgumentException.class, () -> mqpmo.setVersion(version));
    }

    /**
     * Test setting options with invalid (negative) values.
     *
     * @param options - Options to be set.
     */
    @ParameterizedTest
    @ValueSource(longs = {-1L, -10L})
    public void testSetOptionsWithInvalidValues(long options) {
        assertThrows(IllegalArgumentException.class, () -> mqpmo.setOptions(options));
    }

    /**
     * Test setting version with extreme values.
     *
     * @param version - Version to be set.
     */
    @ParameterizedTest
    @ValueSource(ints = {Integer.MAX_VALUE})
    public void testSetVersionWithExtremeValues(int version) {
        mqpmo.setVersion(version);
        assertEquals(version, mqpmo.getVersion());
    }

    /**
     * Test setting options with extreme values.
     *
     * @param options - Options to be set.
     */
    @ParameterizedTest
    @ValueSource(longs = {Long.MAX_VALUE})
    public void testSetOptionsWithExtremeValues(long options) {
        mqpmo.setOptions(options);
        assertEquals(options, mqpmo.getOptions());
    }

}