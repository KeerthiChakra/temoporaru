package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class InputRecordTest {

    private InputRecord inputRecord;

    @BeforeEach
    public void setup() {
        inputRecord = new InputRecord();
    }

    @Test
    public void testDefaultConstructor() {
        assertNotNull(inputRecord);
        assertNull(inputRecord.getRecordType());
        assertNull(inputRecord.getRecordData());
    }

    @ParameterizedTest
    @ValueSource(strings = {"type1", "type2", "", null})
    public void testSetAndGetRecordType(String recordType) {
        inputRecord.setRecordType(recordType);
        assertEquals(recordType, inputRecord.getRecordType());
    }

    @ParameterizedTest
    @ValueSource(strings = {"data1", "data2", "", null})
    public void testSetAndGetRecordData(String recordData) {
        inputRecord.setRecordData(recordData);
        assertEquals(recordData, inputRecord.getRecordData());
    }

    @Test
    public void testSetRecordTypeToNull() {
        inputRecord.setRecordType("type1");
        inputRecord.setRecordType(null);
        assertNull(inputRecord.getRecordType());
    }

    @Test
    public void testSetRecordDataToNull() {
        inputRecord.setRecordData("data1");
        inputRecord.setRecordData(null);
        assertNull(inputRecord.getRecordData());
    }

    @Test
    public void testGetRecordTypeWhenNotSet() {
        assertNull(inputRecord.getRecordType());
    }

    @Test
    public void testGetRecordDataWhenNotSet() {
        assertNull(inputRecord.getRecordData());
    }
}