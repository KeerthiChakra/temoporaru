package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class MQDEFNTest {

    private MQDEFN mqdefn;

    @BeforeEach
    public void setup() {
        mqdefn = new MQDEFN();
    }

    // Test default constructor values
    @Test
    public void testDefaultConstructorValues() {
        assertEquals(MQDEFN.HANDLE_DEFAULT, mqdefn.getConnHandle());
        assertEquals(MQDEFN.HANDLE_DEFAULT, mqdefn.getQueueHandle());
        assertEquals(0, mqdefn.getReturnCode());
    }

    // Test getters and setters for connHandle
    @Test
    public void testGetSetConnHandle() {
        long newConnHandle = 123L;
        mqdefn.setConnHandle(newConnHandle);
        assertEquals(newConnHandle, mqdefn.getConnHandle());
    }

    // Test invalid connHandle value
    @ParameterizedTest
    @ValueSource(longs = {-1, -10, Long.MIN_VALUE})
    public void testInvalidConnHandle(long invalidValue) {
        assertThrows(IllegalArgumentException.class, () -> mqdefn.setConnHandle(invalidValue));
    }

    // Test getters and setters for queueHandle
    @Test
    public void testGetSetQueueHandle() {
        long newQueueHandle = 456L;
        mqdefn.setQueueHandle(newQueueHandle);
        assertEquals(newQueueHandle, mqdefn.getQueueHandle());
    }

    // Test invalid queueHandle value
    @ParameterizedTest
    @ValueSource(longs = {-1, -10, Long.MIN_VALUE})
    public void testInvalidQueueHandle(long invalidValue) {
        assertThrows(IllegalArgumentException.class, () -> mqdefn.setQueueHandle(invalidValue));
    }

    // Test getters and setters for returnCode
    @Test
    public void testGetSetReturnCode() {
        int newReturnCode = 789;
        mqdefn.setReturnCode(newReturnCode);
        assertEquals(newReturnCode, mqdefn.getReturnCode());
    }
}