package com.promptora.invsys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import static org.junit.jupiter.api.Assertions.*;

public class SalesTransactionRecordTest {

    private SalesTransactionRecord salesTransactionRecord;

    @BeforeEach
    void setup() {
        salesTransactionRecord = new SalesTransactionRecord();
    }

    @AfterEach
    void tearDown() {
        // No-op, as the record is recreated for each test
    }

    @Test
    void testDefaultConstructor() {
        assertNotNull(salesTransactionRecord);
        assertNull(salesTransactionRecord.getProductId());
        assertEquals(0, salesTransactionRecord.getStoreId());
        assertEquals(0, salesTransactionRecord.getQuantitySold());
        assertEquals(0.0, salesTransactionRecord.getSalePrice(), 1e-9);
        assertNull(salesTransactionRecord.getSaleDate());
    }

    @ParameterizedTest
    @MethodSource("provideProductIdValues")
    void testSetAndGetProductId(String productId) {
        salesTransactionRecord.setProductId(productId);
        assertEquals(productId, salesTransactionRecord.getProductId());
    }

    private static Stream<Arguments> provideProductIdValues() {
        return Stream.of(
                Arguments.of(null),
                Arguments.of(""),
                Arguments.of("product-123")
        );
    }

    @ParameterizedTest
    @MethodSource("provideStoreIdValues")
    void testSetAndGetStoreId(int storeId) {
        salesTransactionRecord.setStoreId(storeId);
        assertEquals(storeId, salesTransactionRecord.getStoreId());
    }

    private static Stream<Arguments> provideStoreIdValues() {
        return IntStream.of(0, 1, -1, Integer.MAX_VALUE).mapToObj(Arguments::of);
    }

    @ParameterizedTest
    @MethodSource("provideQuantitySoldValues")
    void testSetAndGetQuantitySold(int quantitySold) {
        salesTransactionRecord.setQuantitySold(quantitySold);
        assertEquals(quantitySold, salesTransactionRecord.getQuantitySold());
    }

    private static Stream<Arguments> provideQuantitySoldValues() {
        return IntStream.of(0, 1, -1, Integer.MAX_VALUE).mapToObj(Arguments::of);
    }

    @ParameterizedTest
    @MethodSource("provideSalePriceValues")
    void testSetAndGetSalePrice(double salePrice) {
        salesTransactionRecord.setSalePrice(salePrice);
        assertEquals(salePrice, salesTransactionRecord.getSalePrice(), 1e-9);
    }

    private static Stream<Arguments> provideSalePriceValues() {
        return DoubleStream.of(0.0, 1.0, -1.0, Double.MAX_VALUE).mapToObj(Arguments::of);
    }

    @ParameterizedTest
    @MethodSource("provideSaleDateValues")
    void testSetAndGetSaleDate(String saleDate) {
        salesTransactionRecord.setSaleDate(saleDate);
        assertEquals(saleDate, salesTransactionRecord.getSaleDate());
    }

    private static Stream<Arguments> provideSaleDateValues() {
        return Stream.of(
                Arguments.of(null),
                Arguments.of(""),
                Arguments.of("2022-01-01")
        );
    }
}