package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class StoreReportHeaderTest {

    private StoreReportHeader storeReportHeader;

    @BeforeEach
    void setUp() {
        storeReportHeader = new StoreReportHeader();
    }

    // Test default constructor
    @Test
    void testDefaultConstructor() {
        assertEquals("Daily Sales Report", storeReportHeader.getHeaderTitle());
        assertEquals("", storeReportHeader.getHeaderDate());
    }

    // Test setter and getter for header title
    @ParameterizedTest
    @ValueSource(strings = {"New Title", "Another Title"})
    void testSetAndGetHeaderTitle(String newTitle) {
        storeReportHeader.setHeaderTitle(newTitle);
        assertEquals(newTitle, storeReportHeader.getHeaderTitle());
    }

    // Test edge case: empty string for header title
    @Test
    void testEmptyStringForHeaderTitle() {
        storeReportHeader.setHeaderTitle("");
        assertEquals("", storeReportHeader.getHeaderTitle());
    }

    // Test edge case: null for header title
    @Test
    void testNullForHeaderTitle() {
        assertThrows(NullPointerException.class, () -> storeReportHeader.setHeaderTitle(null));
    }

    // Test setter and getter for header date
    @ParameterizedTest
    @ValueSource(strings = {"2022-01-01", "2023-02-15"})
    void testSetAndGetHeaderDate(String newDate) {
        storeReportHeader.setHeaderDate(newDate);
        assertEquals(newDate, storeReportHeader.getHeaderDate());
    }

    // Test edge case: empty string for header date
    @Test
    void testEmptyStringForHeaderDate() {
        storeReportHeader.setHeaderDate("");
        assertEquals("", storeReportHeader.getHeaderDate());
    }

    // Test edge case: null for header date
    @Test
    void testNullForHeaderDate() {
        assertThrows(NullPointerException.class, () -> storeReportHeader.setHeaderDate(null));
    }
}