package com.promptora.invsys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.io.File;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ProductSearcherTest {

    private InventoryFileReader inventoryFileReaderMock;
    private ProductSearcher productSearcher;

    @BeforeEach
    void setUp() {
        // Mock the inventory file reader to return test data
        inventoryFileReaderMock = mock(InventoryFileReader.class);
        productSearcher = new ProductSearcher();
        productSearcher.inventoryFileReader = inventoryFileReaderMock;
    }

    @AfterEach
    void tearDown() {
        // Reset the mock object for each test
        reset(inventoryFileReaderMock);
    }

    @Test
    void searchProductByName_ProductFound_PrintsProductDetails() throws Exception {
        // Arrange
        String productName = "Test Product";
        InventoryRecord[] inventoryRecords = new InventoryRecord[]{new InventoryRecord(1, productName, 10.99, 5)};
        when(inventoryFileReaderMock.readInventoryRecords()).thenReturn(inventoryRecords);

        // Act and Assert
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        System.setOut(new PrintStream(output));
        productSearcher.searchProductByName(productName);
        String expectedOutput = "Product found:\n" +
                "Product ID: 1\n" +
                "Product Name: Test Product\n" +
                "Product Price: 10.99\n" +
                "Product Quantity: 5";
        assertEquals(expectedOutput, output.toString().trim());
    }

    @Test
    void searchProductByName_ProductNotFound_PrintsNotFoundMessage() throws Exception {
        // Arrange
        String productName = "Non-existent Product";
        InventoryRecord[] inventoryRecords = new InventoryRecord[]{new InventoryRecord(1, "Existing Product", 10.99, 5)};
        when(inventoryFileReaderMock.readInventoryRecords()).thenReturn(inventoryRecords);

        // Act and Assert
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        System.setOut(new PrintStream(output));
        productSearcher.searchProductByName(productName);
        String expectedOutput = "Product not found in inventory.";
        assertEquals(expectedOutput, output.toString().trim());
    }

    @ParameterizedTest(name = "{0} - Product Name should return {1}")
    @CsvSource({
            "Test Product 1, Product found",
            "Non-existent Product, Product not found",
            "", "Product not found", // Empty product name
            "   ", "Product not found" // Whitespace-only product name
    })
    void searchProductByName_Parameterized_ProductNameVariations(String productName, String expectedResult) throws Exception {
        // Arrange
        InventoryRecord[] inventoryRecords;
        if (productName.equals("Test Product 1")) {
            inventoryRecords = new InventoryRecord[]{new InventoryRecord(1, productName, 10.99, 5)};
        } else {
            inventoryRecords = new InventoryRecord[]{new InventoryRecord(1, "Existing Product", 10.99, 5)};
        }
        when(inventoryFileReaderMock.readInventoryRecords()).thenReturn(inventoryRecords);

        // Act and Assert
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        System.setOut(new PrintStream(output));
        productSearcher.searchProductByName(productName);
        if (expectedResult.equals("Product found")) {
            String expectedOutput = "Product found:\n" +
                    "Product ID: 1\n" +
                    "Product Name: Test Product 1\n" +
                    "Product Price: 10.99\n" +
                    "Product Quantity: 5";
            assertEquals(expectedOutput, output.toString().trim());
        } else {
            String expectedOutput = expectedResult;
            assertEquals(expectedOutput, output.toString().trim());
        }
    }

    @Test
    void searchProductByName_NullProductName_ThrowsNullPointerException() throws Exception {
        // Arrange and Act
        assertThrows(NullPointerException.class, () -> productSearcher.searchProductByName(null));
    }

    @Test
    void searchProductByName_InvalidInventoryData_ThrowsRuntimeException() throws Exception {
        // Arrange
        when(inventoryFileReaderMock.readInventoryRecords()).thenThrow(new RuntimeException("Error reading inventory records"));

        // Act and Assert
        assertThrows(RuntimeException.class, () -> productSearcher.searchProductByName("Test Product"));
    }
}