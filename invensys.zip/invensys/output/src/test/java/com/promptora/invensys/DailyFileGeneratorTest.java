package com.promptora.invsys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

public class DailyFileGeneratorTest {

    private static final String TEST_INVENTORY_FILE_NAME = "TEST-INVENTORY.DAT";
    private static final String TEST_SALES_TRANSACTIONS_FILE_NAME = "TEST-SALES.TRANS.DAT";
    private static final String TEST_DAILY_FILE_NAME_PREFIX = "TEST-DAILY.";
    private static final String TEST_LOG_FILE_NAME = "TEST-LOG.DAT";

    private DailyFileGenerator dailyFileGenerator;

    @BeforeEach
    public void setUp() {
        // Create test files and directories if they do not exist
        File inventoryFile = new File(TEST_INVENTORY_FILE_NAME);
        File salesTransactionsFile = new File(TEST_SALES_TRANSACTIONS_FILE_NAME);
        try {
            Files.createDirectories(inventoryFile.getParentFile().toPath());
            Files.createDirectories(salesTransactionsFile.getParentFile().toPath());
        } catch (IOException e) {
            fail("Error creating test files: " + e.getMessage());
        }

        dailyFileGenerator = new DailyFileGenerator();
    }

    @AfterEach
    public void tearDown() throws IOException {
        // Delete generated files
        File dailyFile = new File(TEST_DAILY_FILE_NAME_PREFIX + java.time.LocalDate.now().toString());
        if (dailyFile.exists()) {
            Files.delete(dailyFile.toPath());
        }
        File logFile = new File(TEST_LOG_FILE_NAME);
        if (logFile.exists()) {
            Files.delete(logFile.toPath());
        }

        // Reset file names in DailyFileGenerator
        dailyFileGenerator.getClass().getDeclaredField("INVENTORY_FILE_NAME").set(dailyFileGenerator, DailyFileGenerator.INVENTORY_FILE_NAME);
        dailyFileGenerator.getClass().getDeclaredField("SALES_TRANSACTIONS_FILE_NAME").set(dailyFileGenerator, DailyFileGenerator.SALES_TRANSACTIONS_FILE_NAME);
        dailyFileGenerator.getClass().getDeclaredField("DAILY_FILE_NAME").set(dailyFileGenerator, DailyFileGenerator.DAILY_FILE_NAME);
    }

    @Test
    public void testGenerateDailyFile_HappyPath() throws IOException {
        // Prepare inventory and sales transactions files for testing
        File inventoryFile = new File(TEST_INVENTORY_FILE_NAME);
        Files.write(inventoryFile.toPath(), "Product1,10".getBytes());
        dailyFileGenerator.getClass().getDeclaredField("INVENTORY_FILE_NAME").set(dailyFileGenerator, TEST_INVENTORY_FILE_NAME);

        File salesTransactionsFile = new File(TEST_SALES_TRANSACTIONS_FILE_NAME);
        Files.write(salesTransactionsFile.toPath(), "Product1,5,10.0".getBytes());
        dailyFileGenerator.getClass().getDeclaredField("SALES_TRANSACTIONS_FILE_NAME").set(dailyFileGenerator, TEST_SALES_TRANSACTIONS_FILE_NAME);

        // Set up test Daily File name
        String dailyFileName = TEST_DAILY_FILE_NAME_PREFIX + java.time.LocalDate.now().toString();
        dailyFileGenerator.getClass().getDeclaredField("DAILY_FILE_NAME").set(dailyFileGenerator, dailyFileName);

        // Test generateDailyFile method
        dailyFileGenerator.generateDailyFile();

        // Verify generated files exist and have expected content
        File dailyFile = new File(dailyFileName);
        assertTrue(dailyFile.exists());
        String dailyFileContent = new String(Files.readAllBytes(dailyFile.toPath()));
        assertEquals("Product1,5,10.0", dailyFileContent.trim());

        // Verify log file does not contain error messages
        File logFile = new File(TEST_LOG_FILE_NAME);
        assertFalse(logFile.exists());
    }

    @Test
    public void testGenerateDailyFile_NoInventory() throws IOException {
        // Prepare sales transactions files for testing
        File salesTransactionsFile = new File(TEST_SALES_TRANSACTIONS_FILE_NAME);
        Files.write(salesTransactionsFile.toPath(), "Product1,5,10.0".getBytes());
        dailyFileGenerator.getClass().getDeclaredField("SALES_TRANSACTIONS_FILE_NAME").set(dailyFileGenerator, TEST_SALES_TRANSACTIONS_FILE_NAME);

        // Set up test Daily File name
        String dailyFileName = TEST_DAILY_FILE_NAME_PREFIX + java.time.LocalDate.now().toString();
        dailyFileGenerator.getClass().getDeclaredField("DAILY_FILE_NAME").set(dailyFileGenerator, dailyFileName);

        // Test generateDailyFile method
        assertThrows(IOException.class, () -> dailyFileGenerator.generateDailyFile());

        // Verify generated files do not exist
        File dailyFile = new File(dailyFileName);
        assertFalse(dailyFile.exists());

        // Verify log file contains error message
        File logFile = new File(TEST_LOG_FILE_NAME);
        assertTrue(logFile.exists());
    }

    @Test
    public void testGenerateDailyFile_NoSalesTransactions() throws IOException {
        // Prepare inventory files for testing
        File inventoryFile = new File(TEST_INVENTORY_FILE_NAME);
        Files.write(inventoryFile.toPath(), "Product1,10".getBytes());
        dailyFileGenerator.getClass().getDeclaredField("INVENTORY_FILE_NAME").set(dailyFileGenerator, TEST_INVENTORY_FILE_NAME);

        // Set up test Daily File name
        String dailyFileName = TEST_DAILY_FILE_NAME_PREFIX + java.time.LocalDate.now().toString();
        dailyFileGenerator.getClass().getDeclaredField("DAILY_FILE_NAME").set(dailyFileGenerator, dailyFileName);

        // Test generateDailyFile method
        assertThrows(IOException.class, () -> dailyFileGenerator.generateDailyFile());

        // Verify generated files do not exist
        File dailyFile = new File(dailyFileName);
        assertFalse(dailyFile.exists());

        // Verify log file contains error message
        File logFile = new File(TEST_LOG_FILE_NAME);
        assertTrue(logFile.exists());
    }

    @Test
    public void testGenerateDailyFile_InvalidInventory() throws IOException {
        // Prepare inventory and sales transactions files for testing with invalid data
        File inventoryFile = new File(TEST_INVENTORY_FILE_NAME);
        Files.write(inventoryFile.toPath(), "Product1,abc".getBytes());
        dailyFileGenerator.getClass().getDeclaredField("INVENTORY_FILE_NAME").set(dailyFileGenerator, TEST_INVENTORY_FILE_NAME);

        File salesTransactionsFile = new File(TEST_SALES_TRANSACTIONS_FILE_NAME);
        Files.write(salesTransactionsFile.toPath(), "Product1,5,10.0".getBytes());
        dailyFileGenerator.getClass().getDeclaredField("SALES_TRANSACTIONS_FILE_NAME").set(dailyFileGenerator, TEST_SALES_TRANSACTIONS_FILE_NAME);

        // Set up test Daily File name
        String dailyFileName = TEST_DAILY_FILE_NAME_PREFIX + java.time.LocalDate.now().toString();
        dailyFileGenerator.getClass().getDeclaredField("DAILY_FILE_NAME").set(dailyFileGenerator, dailyFileName);

        // Test generateDailyFile method
        assertThrows(IOException.class, () -> dailyFileGenerator.generateDailyFile());

        // Verify generated files do not exist
        File dailyFile = new File(dailyFileName);
        assertFalse(dailyFile.exists());

        // Verify log file contains error message
        File logFile = new File(TEST_LOG_FILE_NAME);
        assertTrue(logFile.exists());
    }
}