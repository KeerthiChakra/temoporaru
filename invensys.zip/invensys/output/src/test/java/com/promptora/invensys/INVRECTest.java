package com.promptora.invsys;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

public class INVRECTest {

    private INVREC invrec;

    @BeforeEach
    public void setup() {
        invrec = new INVREC();
    }

    @Test
    public void testDefaultConstructor() {
        assertEquals("", invrec.getProductId());
        assertEquals("", invrec.getProductName());
        assertEquals(BigDecimal.ZERO, invrec.getProductPrice());
        assertEquals(0, invrec.getProductQuantity());
    }

    @ParameterizedTest
    @MethodSource("provideTestData")
    public void testConstructor(String productId, String productName, BigDecimal productPrice, int productQuantity) {
        INVREC newInvrec = new INVREC(productId, productName, productPrice, productQuantity);
        assertEquals(productId, newInvrec.getProductId());
        assertEquals(productName, newInvrec.getProductName());
        assertEquals(productPrice, newInvrec.getProductPrice());
        assertEquals(productQuantity, newInvrec.getProductQuantity());
    }

    @Test
    public void testGetters() {
        String productId = "ABC123";
        String productName = "Product A";
        BigDecimal productPrice = new BigDecimal("12.99");
        int productQuantity = 10;

        invrec.setProductId(productId);
        invrec.setProductName(productName);
        invrec.setProductPrice(productPrice);
        invrec.setProductQuantity(productQuantity);

        assertEquals(productId, invrec.getProductId());
        assertEquals(productName, invrec.getProductName());
        assertEquals(productPrice, invrec.getProductPrice());
        assertEquals(productQuantity, invrec.getProductQuantity());
    }

    @Test
    public void testSetters() {
        String newProductId = "DEF456";
        String newProductName = "Product B";
        BigDecimal newProductPrice = new BigDecimal("9.99");
        int newProductQuantity = 20;

        invrec.setProductId(newProductId);
        invrec.setProductName(newProductName);
        invrec.setProductPrice(newProductPrice);
        invrec.setProductQuantity(newProductQuantity);

        assertEquals(newProductId, invrec.getProductId());
        assertEquals(newProductName, invrec.getProductName());
        assertEquals(newProductPrice, invrec.getProductPrice());
        assertEquals(newProductQuantity, invrec.getProductQuantity());
    }

    @ParameterizedTest
    @MethodSource("provideInvalidTestData")
    public void testConstructorExceptions(String productId, String productName, BigDecimal productPrice, int productQuantity) {
        assertThrows(NullPointerException.class, () -> new INVREC(productId, productName, productPrice, productQuantity));
    }

    private static Stream<Arguments> provideTestData() {
        return Stream.of(
                Arguments.of("ABC123", "Product A", new BigDecimal("12.99"), 10),
                Arguments.of("DEF456", "Product B", new BigDecimal("9.99"), 20)
        );
    }

    private static Stream<Arguments> provideInvalidTestData() {
        return Stream.of(
                Arguments.of(null, "Product A", new BigDecimal("12.99"), 10), // null productId
                Arguments.of("ABC123", null, new BigDecimal("12.99"), 10), // null productName
                Arguments.of("ABC123", "Product A", null, 10) // null productPrice
        );
    }
}