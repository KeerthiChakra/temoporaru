package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class InventoryRecordTest {

    private InventoryRecord inventoryRecord;

    @BeforeEach
    public void setup() {
        String productId = "P123";
        String productName = "Product A";
        double productPrice = 19.99;
        int productQuantity = 10;

        inventoryRecord = new InventoryRecord(productId, productName, productPrice, productQuantity);
    }

    @Test
    public void testGetProductId() {
        assertEquals("P123", inventoryRecord.getProductId());
    }

    @Test
    public void testGetProductName() {
        assertEquals("Product A", inventoryRecord.getProductName());
    }

    @Test
    public void testGetProductPrice() {
        assertEquals(19.99, inventoryRecord.getProductPrice(), 0.01);
    }

    @Test
    public void testGetProductQuantity() {
        assertEquals(10, inventoryRecord.getProductQuantity());
    }

    @ParameterizedTest(name = "testSetProductId({arguments})")
    @CsvSource({
            "P456",
            "P789",
            "P012"
    })
    public void testSetProductId(String productId) {
        inventoryRecord.setProductId(productId);
        assertEquals(productId, inventoryRecord.getProductId());
    }

    @ParameterizedTest(name = "testSetProductName({arguments})")
    @CsvSource({
            "Product B",
            "Product C",
            "Product D"
    })
    public void testSetProductName(String productName) {
        inventoryRecord.setProductName(productName);
        assertEquals(productName, inventoryRecord.getProductName());
    }

    @ParameterizedTest(name = "testSetProductPrice({arguments})")
    @CsvSource({
            "9.99",
            "14.99",
            "29.99"
    })
    public void testSetProductPrice(double productPrice) {
        inventoryRecord.setProductPrice(productPrice);
        assertEquals(productPrice, inventoryRecord.getProductPrice(), 0.01);
    }

    @ParameterizedTest(name = "testSetProductQuantity({arguments})")
    @CsvSource({
            "5",
            "15",
            "25"
    })
    public void testSetProductQuantity(int productQuantity) {
        inventoryRecord.setProductQuantity(productQuantity);
        assertEquals(productQuantity, inventoryRecord.getProductQuantity());
    }

    @Test
    public void testNegativeProductPrice() {
        assertThrows(IllegalArgumentException.class, () -> new InventoryRecord("P123", "Product A", -1.0, 10));
    }

    @Test
    public void testZeroProductQuantity() {
        assertThrows(IllegalArgumentException.class, () -> new InventoryRecord("P123", "Product A", 19.99, 0));
    }
}