package com.promptora.invsys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import java.io.ByteArrayInputStream;
import java.io.PrintStream;
import java.util.Scanner;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class InventorySystemTest {

    private InventorySystem inventorySystem;
    private PrintStream originalOut;
    private ByteArrayInputStream in;
    private PrintStream out;

    @BeforeEach
    void setup() {
        inventorySystem = new InventorySystem();
        originalOut = System.out;
        out = new PrintStream(System.out);
        System.setOut(out);
    }

    @AfterEach
    void tearDown() {
        System.setOut(originalOut);
    }

    @Test
    public void testRun_SalesTransactionProcessor() {
        // Arrange
        String input = "1\n3";
        in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        // Act and Assert
        inventorySystem.run();
        assertEquals("Invalid option" + System.lineSeparator(), out.toString());
    }

    @Test
    public void testRun_ProductSearcher() {
        // Arrange
        String input = "2\n3";
        in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        // Act and Assert
        inventorySystem.run();
        assertEquals("Invalid option" + System.lineSeparator(), out.toString());
    }

    @Test
    public void testRun_Exit() {
        // Arrange
        String input = "3";
        in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        // Act and Assert
        assertThrows(IllegalStateException.class, () -> inventorySystem.run());
    }

    @ParameterizedTest(name = "{index} => option={0}")
    @MethodSource("provideInvalidOptions")
    public void testRun_InvalidOption(String input) {
        // Arrange
        in = new ByteArrayInputStream(input.getBytes() + "\n3".getBytes());
        System.setIn(in);

        // Act and Assert
        inventorySystem.run();
        assertEquals("Invalid option" + System.lineSeparator(), out.toString().substring(0, out.toString().indexOf("\r\nInvalid option")));
    }

    private static Arguments[] provideInvalidOptions() {
        return new Arguments[]{
                Arguments.of(""),
                Arguments.of("abc"),
                Arguments.of("12345")
        };
    }
}