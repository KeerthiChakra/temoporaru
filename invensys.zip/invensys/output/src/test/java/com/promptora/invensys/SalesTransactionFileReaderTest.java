package com.promptora.invsys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class SalesTransactionFileReaderTest {

    private SalesTransactionFileReader reader;
    private File testFile;

    @BeforeEach
    void setup() {
        reader = new SalesTransactionFileReader();
        testFile = new File("sales_transactions_test.txt");
    }

    @AfterEach
    void tearDown() throws IOException {
        if (testFile.exists()) {
            testFile.delete();
        }
    }

    @Test
    void testReadSalesTransactions_NominalCase() throws Exception {
        // Create a test file with sample data
        createTestFile("sales1,10.99,2\n" +
                "sales2,5.49,3\n" +
                "sales3,7.99,1");

        SalesTransaction[] transactions = reader.readSalesTransactions();

        assertEquals(3, transactions.length);
        assertEquals(new SalesTransaction("sales1", 10.99, 2), transactions[0]);
        assertEquals(new SalesTransaction("sales2", 5.49, 3), transactions[1]);
        assertEquals(new SalesTransaction("sales3", 7.99, 1), transactions[2]);
    }

    @Test
    void testReadSalesTransactions_EmptyFile() throws Exception {
        // Create an empty test file
        createTestFile("");

        SalesTransaction[] transactions = reader.readSalesTransactions();

        assertArrayEquals(new SalesTransaction[0], transactions);
    }

    @ParameterizedTest(name = "Invalid line format: {0}")
    @CsvSource({
            "invalid,format",
            "missing,field,,",
            ",,empty,fields"
    })
    void testReadSalesTransactions_InvalidLineFormat(String line) throws Exception {
        // Create a test file with an invalid line
        createTestFile(line);

        assertThrows(IOException.class, () -> reader.readSalesTransactions());
    }

    @Test
    void testReadSalesTransactions_FileNotFoundException() throws Exception {
        // Delete the test file to simulate FileNotFound exception
        if (testFile.exists()) {
            testFile.delete();
        }

        assertThrows(FileNotFoundException.class, () -> reader.readSalesTransactions());
    }

    private void createTestFile(String content) throws IOException {
        try (FileWriter writer = new FileWriter(testFile)) {
            writer.write(content);
        }
    }
}