package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class ProductsTableTest {

    private ProductsTable productsTable;

    @BeforeEach
    public void setup() {
        productsTable = new ProductsTable();
    }

    // Test constructor with default values
    @Test
    public void testConstructorWithDefaultValues() {
        assertEquals("", productsTable.getProductId());
        assertEquals("", productsTable.getProductName());
        assertEquals("", productsTable.getProductDescription());
        assertEquals(0.0, productsTable.getUnitPrice(), 0.01);
        assertEquals(0, productsTable.getQuantityInStock());
        assertEquals(0, productsTable.getReorderLevel());
        assertEquals(0, productsTable.getSupplierId());
    }

    // Test getters and setters for productId
    @Test
    public void testGetAndSetProductId() {
        String expected = "12345";
        productsTable.setProductId(expected);
        assertEquals(expected, productsTable.getProductId());

        // Test edge case: max length
        expected = repeatString("A", ProductsTable.MAX_PRODUCT_ID_LENGTH);
        productsTable.setProductId(expected);
        assertEquals(expected, productsTable.getProductId());
    }

    // Test getters and setters for productName
    @Test
    public void testGetAndSetProductName() {
        String expected = "Product Name";
        productsTable.setProductName(expected);
        assertEquals(expected, productsTable.getProductName());

        // Test edge case: max length
        expected = repeatString("A", ProductsTable.MAX_PRODUCT_NAME_LENGTH);
        productsTable.setProductName(expected);
        assertEquals(expected, productsTable.getProductName());
    }

    // Test getters and setters for productDescription
    @Test
    public void testGetAndSetProductDescription() {
        String expected = "This is a product description.";
        productsTable.setProductDescription(expected);
        assertEquals(expected, productsTable.getProductDescription());

        // Test edge case: max length
        expected = repeatString("A", ProductsTable.MAX_PRODUCT_DESCRIPTION_LENGTH);
        productsTable.setProductDescription(expected);
        assertEquals(expected, productsTable.getProductDescription());
    }

    // Test getters and setters for unitPrice
    @Test
    public void testGetAndSetUnitPrice() {
        double expected = 10.99;
        productsTable.setUnitPrice(expected);
        assertEquals(expected, productsTable.getUnitPrice(), 0.01);

        // Test edge case: zero price
        expected = 0.0;
        productsTable.setUnitPrice(expected);
        assertEquals(expected, productsTable.getUnitPrice(), 0.01);
    }

    // Test getters and setters for quantityInStock
    @Test
    public void testGetAndSetQuantityInStock() {
        int expected = 100;
        productsTable.setQuantityInStock(expected);
        assertEquals(expected, productsTable.getQuantityInStock());

        // Test edge case: zero stock
        expected = 0;
        productsTable.setQuantityInStock(expected);
        assertEquals(expected, productsTable.getQuantityInStock());
    }

    // Test getters and setters for reorderLevel
    @Test
    public void testGetAndSetReorderLevel() {
        int expected = 50;
        productsTable.setReorderLevel(expected);
        assertEquals(expected, productsTable.getReorderLevel());

        // Test edge case: zero reorder level
        expected = 0;
        productsTable.setReorderLevel(expected);
        assertEquals(expected, productsTable.getReorderLevel());
    }

    // Test getters and setters for supplierId
    @Test
    public void testGetAndSetSupplierId() {
        int expected = 123;
        productsTable.setSupplierId(expected);
        assertEquals(expected, productsTable.getSupplierId());

        // Test edge case: zero supplier id
        expected = 0;
        productsTable.setSupplierId(expected);
        assertEquals(expected, productsTable.getSupplierId());
    }

    // Helper method to repeat a string n times
    private String repeatString(String str, int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            sb.append(str);
        }
        return sb.toString();
    }
}