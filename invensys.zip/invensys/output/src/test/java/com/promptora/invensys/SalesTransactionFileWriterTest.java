package com.promptora.invsys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
#import org.junit.jupiter.params.provider.MethodSource;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.stream.Stream;

public class SalesTransactionFileWriterTest {

    private static final String FILE_NAME = "sales_transactions.txt";
    private SalesTransactionFileWriter writer;

    @BeforeEach
    public void setup() {
        writer = new SalesTransactionFileWriter();
    }

    @AfterEach
    public void tearDown() throws IOException {
        // Delete the file after each test to ensure a clean slate
        File file = new File(FILE_NAME);
        if (file.exists()) {
            file.delete();
        }
    }

    @Test
    public void testWriteSalesTransactions_NormalCase() throws IOException {
        SalesTransaction[] salesTransactions = {
                new SalesTransaction(1, 10.99, 2),
                new SalesTransaction(2, 5.99, 3)
        };

        writer.writeSalesTransactions(salesTransactions);

        // Verify the file exists
        File file = new File(FILE_NAME);
        assert file.exists();

        // Verify the file contents
        try (FileWriter fileReader = new FileWriter(file)) {
            String expectedContents = "1,10.99,2\n" +
                    "2,5.99,3\n";
            StringBuilder actualContents = new StringBuilder();
            int c;
            while ((c = fileReader.read()) != -1) {
                actualContents.append((char) c);
            }
            assert expectedContents.equals(actualContents.toString());
        }
    }

    @Test
    public void testWriteSalesTransactions_EmptyArray() throws IOException {
        SalesTransaction[] salesTransactions = new SalesTransaction[0];

        writer.writeSalesTransactions(salesTransactions);

        // Verify the file exists
        File file = new File(FILE_NAME);
        assert !file.exists();
    }

    @ParameterizedTest
    @MethodSource("invalidFileNames")
    public void testWriteSalesTransactions_InvalidFileName(String invalidFileName) {
        SalesTransaction[] salesTransactions = {
                new SalesTransaction(1, 10.99, 2)
        };

        try {
            writer.writeSalesTransactions(salesTransactions);
            assert false; // Should throw an exception
        } catch (IOException e) {
            assert true;
        }
    }

    private static Stream<Arguments> invalidFileNames() {
        return Stream.of(
                Arguments.of(null),
                Arguments.of("")
        );
    }

    @Test
    public void testWriteSalesTransactions_NullArray() {
        try {
            writer.writeSalesTransactions(null);
            assert false; // Should throw an exception
        } catch (NullPointerException e) {
            assert true;
        }
    }

    @Test
    public void testWriteSalesTransactions_NullElementInArray() throws IOException {
        SalesTransaction[] salesTransactions = {
                new SalesTransaction(1, 10.99, 2),
                null,
                new SalesTransaction(3, 5.99, 4)
        };

        try {
            writer.writeSalesTransactions(salesTransactions);
            assert false; // Should throw an exception
        } catch (NullPointerException e) {
            assert true;
        }
    }

    @Test
    public void testWriteSalesTransactions_IOError() throws IOException {
        // Simulate an I/O error by making the file unwritable
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            file.createNewFile();
        }
        file.setWritable(false);

        SalesTransaction[] salesTransactions = {
                new SalesTransaction(1, 10.99, 2)
        };

        try {
            writer.writeSalesTransactions(salesTransactions);
            assert false; // Should throw an exception
        } catch (IOException e) {
            assert true;
        } finally {
            file.setWritable(true);
        }
    }

    private static class SalesTransaction {
        private int transactionId;
        private double saleAmount;
        private int quantitySold;

        public SalesTransaction(int transactionId, double saleAmount, int quantitySold) {
            this.transactionId = transactionId;
            this.saleAmount = saleAmount;
            this.quantitySold = quantitySold;
        }

        public int getTransactionId() {
            return transactionId;
        }

        public double getSaleAmount() {
            return saleAmount;
        }

        public int getQuantitySold() {
            return quantitySold;
        }
    }
}