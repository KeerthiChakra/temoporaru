package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class SalesTransactionTest {

    private SalesTransaction salesTransaction;

    @BeforeEach
    void setUp() {
        salesTransaction = new SalesTransaction("TXN-123", 100.0, 2);
    }

    // Test normal cases
    @Test
    void testGetters() {
        assertEquals("TXN-123", salesTransaction.getTransactionId());
        assertEquals(100.0, salesTransaction.getSaleAmount(), 0.01);
        assertEquals(2, salesTransaction.getQuantitySold());
    }

    // Test edge cases for quantity sold
    @ParameterizedTest
    @MethodSource("quantitySoldEdgeCases")
    void testQuantitySold(int quantitySold) {
        SalesTransaction tx = new SalesTransaction("TXN-123", 100.0, quantitySold);
        assertEquals(quantitySold, tx.getQuantitySold());
    }

    private static Stream<Arguments> quantitySoldEdgeCases() {
        return Stream.of(
                Arguments.arguments(0),
                Arguments.arguments(-1),
                Arguments.arguments(1)
        );
    }

    // Test edge cases for sale amount
    @ParameterizedTest
    @MethodSource("saleAmountEdgeCases")
    void testSaleAmount(double saleAmount) {
        SalesTransaction tx = new SalesTransaction("TXN-123", saleAmount, 2);
        assertEquals(saleAmount, tx.getSaleAmount(), 0.01);
    }

    private static Stream<Arguments> saleAmountEdgeCases() {
        return Stream.of(
                Arguments.arguments(0.0),
                Arguments.arguments(-1.0),
                Arguments.arguments(Double.MAX_VALUE)
        );
    }

    // Test exceptions for transaction ID
    @Test
    void testTransactionIdNull() {
        assertThrows(NullPointerException.class, () -> new SalesTransaction(null, 100.0, 2));
    }

    @Test
    void testTransactionIdEmpty() {
        assertThrows(IllegalArgumentException.class, () -> new SalesTransaction("", 100.0, 2));
    }

    // Test exceptions for quantity sold
    @Test
    void testQuantitySoldNegative() {
        assertThrows(IllegalArgumentException.class, () -> new SalesTransaction("TXN-123", 100.0, -2));
    }
}