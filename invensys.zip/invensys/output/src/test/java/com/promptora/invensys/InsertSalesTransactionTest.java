package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class InsertSalesTransactionTest {

    private SQL_OPS sqlOpsMock;
    private SalesTransactionsTable salesTransactionMock;
    private Connection connectionMock;
    private PreparedStatement pstmtMock;

    @BeforeEach
    void setUp() {
        sqlOpsMock = mock(SQL_OPS.class);
        salesTransactionMock = mock(SalesTransactionsTable.class);
        connectionMock = mock(Connection.class);
        pstmtMock = mock(PreparedStatement.class);

        when(sqlOpsMock.getConnection()).thenReturn(connectionMock);
        when(connectionMock.prepareStatement(anyString())).thenReturn(pstmtMock);
    }

    @Test
    void testInsertSalesTransaction_Success() throws SQLException {
        // Given
        String salesTransactionId = "123";
        double amount = 10.99;
        LocalDate transactionDate = LocalDate.now();
        when(salesTransactionMock.getSalesTransactionId()).thenReturn(salesTransactionId);
        when(salesTransactionMock.getAmount()).thenReturn(amount);
        when(salesTransactionMock.getTransactionDate()).thenReturn(transactionDate);

        // When
        InsertSalesTransaction insertSalesTransaction = new InsertSalesTransaction(sqlOpsMock, salesTransactionMock);
        insertSalesTransaction.insert();

        // Then
        verify(pstmtMock).setString(1, salesTransactionId);
        verify(pstmtMock).setDouble(2, amount);
        verify(pstmtMock).setDate(3, java.sql.Date.valueOf(transactionDate));
        verify(pstmtMock).executeUpdate();
        verify(connectionMock).commit();
    }

    @Test
    void testInsertSalesTransaction_Failure() throws SQLException {
        // Given
        doThrow(SQLException.class).when(pstmtMock).executeUpdate();

        // When and Then
        assertThrows(SQLException.class, () -> {
            InsertSalesTransaction insertSalesTransaction = new InsertSalesTransaction(sqlOpsMock, salesTransactionMock);
            insertSalesTransaction.insert();
        });
        verify(connectionMock).rollback();
    }

    @ParameterizedTest(name = "testInsertSalesTransaction_InvalidInput_{index}")
    @MethodSource("invalidInputProvider")
    void testInsertSalesTransaction_InvalidInput(String salesTransactionId, double amount, LocalDate transactionDate) {
        // Given
        when(salesTransactionMock.getSalesTransactionId()).thenReturn(salesTransactionId);
        when(salesTransactionMock.getAmount()).thenReturn(amount);
        when(salesTransactionMock.getTransactionDate()).thenReturn(transactionDate);

        // When and Then
        assertThrows(SQLException.class, () -> {
            InsertSalesTransaction insertSalesTransaction = new InsertSalesTransaction(sqlOpsMock, salesTransactionMock);
            insertSalesTransaction.insert();
        });
    }

    private static Stream<Arguments> invalidInputProvider() {
        return Stream.of(
                Arguments.of("", 10.99, LocalDate.now()), // Empty sales transaction ID
                Arguments.of("123", -1.0, LocalDate.now()), // Negative amount
                Arguments.of("123", 10.99, null) // Null transaction date
        );
    }

    @Test
    void testInsertSalesTransaction_NullInput() {
        // Given
        when(salesTransactionMock.getSalesTransactionId()).thenReturn(null);
        when(salesTransactionMock.getAmount()).thenReturn(10.99);
        when(salesTransactionMock.getTransactionDate()).thenReturn(LocalDate.now());

        // When and Then
        assertThrows(SQLException.class, () -> {
            InsertSalesTransaction insertSalesTransaction = new InsertSalesTransaction(sqlOpsMock, salesTransactionMock);
            insertSalesTransaction.insert();
        });
    }
}