package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class SalesTransactionScreenTest {

    private SalesTransactionScreen salesTransactionScreen;

    @BeforeEach
    void setUp() {
        salesTransactionScreen = new SalesTransactionScreen();
    }

    @Test
    public void testDefaultValues() {
        assertEquals(null, salesTransactionScreen.getProductName());
        assertEquals(null, salesTransactionScreen.getQuantitySold());
        assertEquals(null, salesTransactionScreen.getSalePrice());
        assertEquals(null, salesTransactionScreen.getSaleDate());
        assertEquals(null, salesTransactionScreen.getStoreId());
        assertEquals(null, salesTransactionScreen.getEnter());
        assertEquals(null, salesTransactionScreen.getCancel());
    }

    @ParameterizedTest
    @MethodSource("provideProductNameTestData")
    public void testSetProductName(String productName) {
        salesTransactionScreen.setProductName(productName);
        assertEquals(productName, salesTransactionScreen.getProductName());
    }

    private static Stream<Arguments> provideProductNameTestData() {
        return Stream.of(
                Arguments.arguments("Product A"),
                Arguments.arguments("")
        );
    }

    @Test
    public void testSetProductNameExceedsMaxLength() {
        String productName = "This is a very long product name that exceeds the max length";
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> salesTransactionScreen.setProductName(productName));
        assertEquals("Product name exceeds maximum length of 50", exception.getMessage());
    }

    @ParameterizedTest
    @MethodSource("provideQuantitySoldTestData")
    public void testSetQuantitySold(Integer quantitySold) {
        salesTransactionScreen.setQuantitySold(quantitySold);
        assertEquals(quantitySold, salesTransactionScreen.getQuantitySold());
    }

    private static Stream<Arguments> provideQuantitySoldTestData() {
        return Stream.of(
                Arguments.arguments(10),
                Arguments.arguments(null)
        );
    }

    @Test
    public void testSetQuantitySoldExceedsMaxLength() {
        Integer quantitySold = 12345;
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> salesTransactionScreen.setQuantitySold(quantitySold));
        assertEquals("Quantity sold exceeds maximum length of 4", exception.getMessage());
    }

    @ParameterizedTest
    @MethodSource("provideSalePriceTestData")
    public void testSetSalePrice(Double salePrice) {
        salesTransactionScreen.setSalePrice(salePrice);
        assertEquals(salePrice, salesTransactionScreen.getSalePrice());
    }

    private static Stream<Arguments> provideSalePriceTestData() {
        return Stream.of(
                Arguments.arguments(10.99),
                Arguments.arguments(null)
        );
    }

    @Test
    public void testSetSalePriceExceedsMaxLength() {
        Double salePrice = 1234567.89;
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> salesTransactionScreen.setSalePrice(salePrice));
        assertEquals("Sale price exceeds maximum length of 7", exception.getMessage());
    }

    @ParameterizedTest
    @MethodSource("provideSaleDateTestData")
    public void testSetSaleDate(String saleDate) {
        salesTransactionScreen.setSaleDate(saleDate);
        assertEquals(saleDate, salesTransactionScreen.getSaleDate());
    }

    private static Stream<Arguments> provideSaleDateTestData() {
        return Stream.of(
                Arguments.arguments("2022-01-01"),
                Arguments.arguments("")
        );
    }

    @Test
    public void testSetSaleDateExceedsMaxLength() {
        String saleDate = "202201012";
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> salesTransactionScreen.setSaleDate(saleDate));
        assertEquals("Sale date exceeds maximum length of 8", exception.getMessage());
    }

    @ParameterizedTest
    @MethodSource("provideStoreIdTestData")
    public void testSetStoreId(Integer storeId) {
        salesTransactionScreen.setStoreId(storeId);
        assertEquals(storeId, salesTransactionScreen.getStoreId());
    }

    private static Stream<Arguments> provideStoreIdTestData() {
        return Stream.of(
                Arguments.arguments(10),
                Arguments.arguments(null)
        );
    }

    @Test
    public void testSetStoreIdExceedsMaxLength() {
        Integer storeId = 12345;
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> salesTransactionScreen.setStoreId(storeId));
        assertEquals("Store ID exceeds maximum length of 4", exception.getMessage());
    }
}