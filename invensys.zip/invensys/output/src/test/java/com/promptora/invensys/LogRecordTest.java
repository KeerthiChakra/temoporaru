package com.promptora.invsys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class LogRecordTest {

    private LogRecord logRecord;

    @BeforeEach
    public void setUp() {
        logRecord = new LogRecord();
    }

    @AfterEach
    public void tearDown() {
        logRecord = null;
    }

    @Test
    public void testDefaultConstructorAndGetLogData() {
        assertEquals("", logRecord.getLogData(), "Expected default log data to be empty string");
    }

    @Test
    public void testSetAndGetLogData_NormalCase() {
        String expectedLogData = "This is a normal log record";
        logRecord.setLogData(expectedLogData);
        assertEquals(expectedLogData, logRecord.getLogData(), "Expected log data to match the set value");
    }

    @Test
    public void testSetAndGetLogData_EdgeCase_EmptyString() {
        String expectedLogData = "";
        logRecord.setLogData(expectedLogData);
        assertEquals(expectedLogData, logRecord.getLogData(), "Expected log data to match the set empty string");
    }

    @Test
    public void testSetAndGetLogData_EdgeCase_NullValue() {
        assertThrows(NullPointerException.class, () -> logRecord.setLogData(null), "Expected NullPointerException when setting null log data");
    }

    @Test
    public void testGetLogData_MultipleCalls() {
        String expectedLogData = "This is a normal log record";
        logRecord.setLogData(expectedLogData);
        assertEquals(expectedLogData, logRecord.getLogData(), "Expected log data to match the set value in first call");
        assertEquals(expectedLogData, logRecord.getLogData(), "Expected log data to match the set value in second call");
    }

    @Test
    public void testSetLogData_MultipleCalls() {
        String expectedLogData1 = "This is a normal log record";
        String expectedLogData2 = "This is another normal log record";
        logRecord.setLogData(expectedLogData1);
        assertEquals(expectedLogData1, logRecord.getLogData(), "Expected log data to match the first set value");
        logRecord.setLogData(expectedLogData2);
        assertEquals(expectedLogData2, logRecord.getLogData(), "Expected log data to match the second set value");
    }

    @Test
    public void testParameterizedSetAndGetLogData() {
        String[] logDataValues = {"This is a normal log record", "", "Another log record"};
        for (String logDataValue : logDataValues) {
            logRecord.setLogData(logDataValue);
            assertEquals(logDataValue, logRecord.getLogData(), "Expected log data to match the set value");
        }
    }
}