package com.promptora.invsys;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Properties;

public class DailySalesReportTest {

    private static Connection conn;

    @BeforeEach
    public void setup() throws SQLException {
        Properties props = new Properties();
        props.setProperty("user", "root");
        props.setProperty("password", "password");

        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sales", props);
    }

    @AfterEach
    public void tearDown() throws SQLException {
        if (conn != null) {
            conn.close();
        }
    }

    @Test
    public void testGenerateDailySalesReport_HappyPath() throws SQLException {
        // Test setup
        Statement stmt = conn.createStatement();

        // Create Stores table and insert data
        stmt.execute("CREATE TABLE IF NOT EXISTS Stores (StoreID INT PRIMARY KEY, StoreName VARCHAR(255))");
        stmt.execute("INSERT INTO Stores (StoreID, StoreName) VALUES (1, 'Store1'), (2, 'Store2')");

        // Create SalesTransactions table and insert data
        stmt.execute("CREATE TABLE IF NOT EXISTS SalesTransactions (SaleID INT PRIMARY KEY, StoreID INT, SaleDate DATE, Quantity INT, SalePrice DECIMAL(10, 2))");
        stmt.execute("INSERT INTO SalesTransactions (SaleID, StoreID, SaleDate, Quantity, SalePrice) VALUES " +
                "(1, 1, '2023-03-01', 5, 100.00), " +
                "(2, 1, '2023-03-01', 10, 200.00), " +
                "(3, 2, '2023-03-01', 7, 50.00)");

        // Test execution
        String actualOutput = DailySalesReport.generateDailySalesReport(conn);

        // Test verification
        Assertions.assertNotNull(actualOutput);
        Assertions.assertTrue(actualOutput.contains("Store1"));
        Assertions.assertTrue(actualOutput.contains("Store2"));

        // Cleanup
        stmt.execute("DROP TABLE SalesTransactions");
        stmt.execute("DROP TABLE Stores");
    }

    @Test
    public void testGenerateDailySalesReport_NoData() throws SQLException {
        // Test setup
        Statement stmt = conn.createStatement();

        // Create empty tables
        stmt.execute("CREATE TABLE IF NOT EXISTS Stores (StoreID INT PRIMARY KEY, StoreName VARCHAR(255))");
        stmt.execute("CREATE TABLE IF NOT EXISTS SalesTransactions (SaleID INT PRIMARY KEY, StoreID INT, SaleDate DATE, Quantity INT, SalePrice DECIMAL(10, 2))");

        // Test execution
        String actualOutput = DailySalesReport.generateDailySalesReport(conn);

        // Test verification
        Assertions.assertNotNull(actualOutput);
        Assertions.assertTrue(actualOutput.contains("No data available"));

        // Cleanup
        stmt.execute("DROP TABLE SalesTransactions");
        stmt.execute("DROP TABLE Stores");
    }

    @Test
    public void testGenerateDailySalesReport_NullConnection() {
        Assertions.assertThrows(SQLException.class, () -> DailySalesReport.generateDailySalesReport(null));
    }

    @ParameterizedTest
    @CsvSource({
            "jdbc:mysql://localhost:3306/sales, root, password",
            "jdbc:mysql://localhost:3307/sales, user, pass"
    })
    public void testGenerateDailySalesReport_InvalidConnection(String dbUrl, String username, String password) {
        // Test setup
        Properties props = new Properties();
        props.setProperty("user", username);
        props.setProperty("password", password);

        Assertions.assertThrows(SQLException.class, () -> DriverManager.getConnection(dbUrl, props));
    }

    @Test
    public void testGenerateDailySalesReport_SQLException() throws SQLException {
        // Test setup
        Statement stmt = conn.createStatement();

        // Create invalid table structure
        stmt.execute("CREATE TABLE Stores (StoreID INT PRIMARY KEY, StoreName VARCHAR(255))");
        stmt.execute("INSERT INTO Stores (StoreID, StoreName) VALUES (1, 'Store1'), (2, 'Store2')");

        // Test execution with incorrect SQL query
        Assertions.assertThrows(SQLException.class, () -> DailySalesReport.generateDailySalesReport(conn));

        // Cleanup
        stmt.execute("DROP TABLE Stores");
    }
}

// Modify the DailySalesReport class to make it testable

class DailySalesReport {
    public static String generateDailySalesReport(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            ResultSet rs;

            Date currentDate = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String dateString = dateFormat.format(currentDate);

            // Generate daily sales report
            String query = "SELECT s.StoreID, s.StoreName, SUM(st.Quantity) AS TotalQuantitySold, "
                    + "SUM(st.SalePrice * st.Quantity) AS TotalSalesAmount "
                    + "FROM SalesTransactions st JOIN Stores s ON st.StoreID = s.StoreID "
                    + "WHERE st.SaleDate = '" + dateString + "' GROUP BY s.StoreID, s.StoreName";

            rs = stmt.executeQuery(query);

            // Print report header
            StringBuilder output = new StringBuilder();
            output.append("Daily Sales Report").append("\n");
            output.append("--------------------").append("\n");

            // Print report records
            if (rs.next()) {
                do {
                    int storeId = rs.getInt(1);
                    String storeName = rs.getString(2);
                    double totalQuantitySold = rs.getDouble(3);
                    double totalSalesAmount = rs.getDouble(4);

                    output.append(storeId).append("\t").append(storeName).append("\t").append(totalQuantitySold).append("\t").append(totalSalesAmount).append("\n");
                } while (rs.next());
            } else {
                output.append("No data available").append("\n");
            }

            // Print report footer
            output.append("--------------------").append("\n");
            output.append("End of Report");

            return output.toString();
        }
    }
}