package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class OrderReportRecordTest {

    private OrderReportRecord orderReportRecord;

    @BeforeEach
    void setup() {
        orderReportRecord = new OrderReportRecord();
    }

    // Test normal cases for getters and setters

    @Test
    public void testGettersAndSetters_NominalCase_OrderId() {
        String orderId = "12345";
        orderReportRecord.setOrderId(orderId);
        assertEquals(orderId, orderReportRecord.getOrderId());
    }

    @Test
    public void testGettersAndSetters_NominalCase_ProductId() {
        String productId = "67890";
        orderReportRecord.setProductId(productId);
        assertEquals(productId, orderReportRecord.getProductId());
    }

    @Test
    public void testGettersAndSetters_NominalCase_OrderDate() {
        String orderDate = "20220101";
        orderReportRecord.setOrderDate(orderDate);
        assertEquals(orderDate, orderReportRecord.getOrderDate());
    }

    @Test
    public void testGettersAndSetters_NominalCase_OrderQuantity() {
        String orderQuantity = "00010";
        orderReportRecord.setOrderQuantity(orderQuantity);
        assertEquals(orderQuantity, orderReportRecord.getOrderQuantity());
    }

    // Test edge cases for getters and setters

    @ParameterizedTest
    @ValueSource(strings = {"", "1", "12", "123", "1234"})
    public void testSetOrderId_EdgeCase_TooShort(String orderId) {
        assertThrows(IllegalArgumentException.class, () -> orderReportRecord.setOrderId(orderId));
    }

    @ParameterizedTest
    @ValueSource(strings = {"123456", "1234567", "12345678", "123456789"})
    public void testSetOrderId_EdgeCase_TooLong(String orderId) {
        assertThrows(IllegalArgumentException.class, () -> orderReportRecord.setOrderId(orderId));
    }

    // Repeat similar tests for productId, orderDate and orderQuantity

    @ParameterizedTest
    @ValueSource(strings = {"", "1", "12", "123", "1234"})
    public void testSetProductId_EdgeCase_TooShort(String productId) {
        assertThrows(IllegalArgumentException.class, () -> orderReportRecord.setProductId(productId));
    }

    @ParameterizedTest
    @ValueSource(strings = {"123456", "1234567", "12345678", "123456789"})
    public void testSetProductId_EdgeCase_TooLong(String productId) {
        assertThrows(IllegalArgumentException.class, () -> orderReportRecord.setProductId(productId));
    }

    // Repeat similar tests for orderDate and orderQuantity

    @ParameterizedTest
    @ValueSource(strings = {"", "1", "12", "1234567"})
    public void testSetOrderDate_EdgeCase_TooShort(String orderDate) {
        assertThrows(IllegalArgumentException.class, () -> orderReportRecord.setOrderDate(orderDate));
    }

    @ParameterizedTest
    @ValueSource(strings = {"123456789", "1234567890", "12345678901"})
    public void testSetOrderDate_EdgeCase_TooLong(String orderDate) {
        assertThrows(IllegalArgumentException.class, () -> orderReportRecord.setOrderDate(orderDate));
    }

    // Repeat similar tests for orderQuantity

    @ParameterizedTest
    @ValueSource(strings = {"", "1", "12", "1234"})
    public void testSetOrderQuantity_EdgeCase_TooShort(String orderQuantity) {
        assertThrows(IllegalArgumentException.class, () -> orderReportRecord.setOrderQuantity(orderQuantity));
    }

    @ParameterizedTest
    @ValueSource(strings = {"123456", "1234567", "12345678", "123456789"})
    public void testSetOrderQuantity_EdgeCase_TooLong(String orderQuantity) {
        assertThrows(IllegalArgumentException.class, () -> orderReportRecord.setOrderQuantity(orderQuantity));
    }

    // Test toString() method

    @Test
    public void testToString_NominalCase() {
        String orderId = "12345";
        String productId = "67890";
        String orderDate = "20220101";
        String orderQuantity = "00010";

        orderReportRecord.setOrderId(orderId);
        orderReportRecord.setProductId(productId);
        orderReportRecord.setOrderDate(orderDate);
        orderReportRecord.setOrderQuantity(orderQuantity);

        String expectedToString = "OrderReportRecord{orderId='" + orderId + '\'' +
                ", productId='" + productId + '\'' +
                ", orderDate='" + orderDate + '\'' +
                ", orderQuantity='" + orderQuantity + '\'' +
                '}';

        assertEquals(expectedToString, orderReportRecord.toString());
    }
}