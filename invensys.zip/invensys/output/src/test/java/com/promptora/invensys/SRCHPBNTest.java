package com.promptora.invsys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

public class SRCHPBNTest {

    private SRCHPBN srchpbn;

    @BeforeEach
    void setup() {
        srchpbn = new SRCHPBN();
    }

    @AfterEach
    void tearDown() {
        // No-op for now, but you can add any necessary cleanup code here
    }

    @Test
    void testSearchProductByName_NormalCase() {
        // Arrange: Set up a mock input stream with a product name
        String productName = "Widget";
        InputStream inputStream = new ByteArrayInputStream(productName.getBytes());
        System.setIn(inputStream);

        // Act: Call the searchProductByName method
        srchpbn.searchProductByName();

        // Assert: Verify that the product name was set correctly
        assertEquals(productName, srchpbn.getWsProductName());
    }

    @ParameterizedTest
    @CsvSource({
            "Empty String",
            "   ",
            "\t"
    })
    void testSearchProductByName_EmptyProductName(String productName) {
        // Arrange: Set up a mock input stream with an empty product name
        InputStream inputStream = new ByteArrayInputStream(productName.getBytes());
        System.setIn(inputStream);

        // Act and Assert: Call the searchProductByName method and verify that it doesn't throw an exception
        assertDoesNotThrow(() -> srchpbn.searchProductByName());

        // Assert: Verify that the product name was set to the empty string
        assertEquals(productName, srchpbn.getWsProductName());
    }

    @Test
    void testSearchProductByName_NullProductName() {
        // Arrange: Set up a mock input stream with a null product name (i.e., Ctrl+D on Unix-like systems)
        InputStream inputStream = new ByteArrayInputStream(new byte[0]);
        System.setIn(inputStream);

        // Act and Assert: Call the searchProductByName method and verify that it throws an exception
        assertThrows(NullPointerException.class, () -> srchpbn.searchProductByName());
    }

    @Test
    void testGetWsProductName_NormalCase() {
        // Arrange: Set a product name using the setter method
        String productName = "Widget";
        srchpbn.setWsProductName(productName);

        // Act and Assert: Verify that the getter method returns the correct product name
        assertEquals(productName, srchpbn.getWsProductName());
    }

    @Test
    void testSetWsProductName_NormalCase() {
        // Arrange: Set a product name using the setter method
        String productName = "Widget";
        srchpbn.setWsProductName(productName);

        // Act and Assert: Verify that the getter method returns the correct product name
        assertEquals(productName, srchpbn.getWsProductName());
    }

    @Test
    void testSetWsProductName_NullProductName() {
        // Arrange: Set a null product name using the setter method

        // Act and Assert: Call the setter method with a null product name and verify that it doesn't throw an exception
        assertDoesNotThrow(() -> srchpbn.setWsProductName(null));

        // Assert: Verify that the getter method returns null
        assertNull(srchpbn.getWsProductName());
    }
}