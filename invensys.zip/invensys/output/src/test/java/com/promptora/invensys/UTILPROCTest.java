package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class UTILPROCTest {

    private UTILPROC utilproc;

    @BeforeEach
    public void setup() {
        utilproc = new UTILPROC();
    }

    // Test cases for getMissCount()
    @Test
    public void testGetMissCount_DefaultValue() {
        assertEquals(0, utilproc.getMissCount());
    }

    @Test
    public void testGetMissCount_PositiveValue() {
        int expected = 10;
        utilproc.setMissCount(expected);
        assertEquals(expected, utilproc.getMissCount());
    }

    // Test cases for setMissCount()
    @Test
    public void testSetMissCount_PositiveValue() {
        int value = 5;
        utilproc.setMissCount(value);
        assertEquals(value, utilproc.getMissCount());
    }

    @ParameterizedTest(name = "testSetMissCount_InvalidValue_{index}")
    @CsvSource({
            "-1",
            "10000"
    })
    public void testSetMissCount_InvalidValue(int value) {
        assertThrows(IllegalArgumentException.class, () -> utilproc.setMissCount(value));
    }

    // Test cases for getInsertCount()
    @Test
    public void testGetInsertCount_DefaultValue() {
        assertEquals(0, utilproc.getInsertCount());
    }

    @Test
    public void testGetInsertCount_PositiveValue() {
        int expected = 20;
        utilproc.setInsertCount(expected);
        assertEquals(expected, utilproc.getInsertCount());
    }

    // Test cases for setInsertCount()
    @Test
    public void testSetInsertCount_PositiveValue() {
        int value = 10;
        utilproc.setInsertCount(value);
        assertEquals(value, utilproc.getInsertCount());
    }

    @ParameterizedTest(name = "testSetInsertCount_InvalidValue_{index}")
    @CsvSource({
            "-1",
            "10000"
    })
    public void testSetInsertCount_InvalidValue(int value) {
        assertThrows(IllegalArgumentException.class, () -> utilproc.setInsertCount(value));
    }

    // Test cases for getRecordCount()
    @Test
    public void testGetRecordCount_DefaultValue() {
        assertEquals(0, utilproc.getRecordCount());
    }

    @Test
    public void testGetRecordCount_PositiveValue() {
        int expected = 50;
        utilproc.setRecordCount(expected);
        assertEquals(expected, utilproc.getRecordCount());
    }

    // Test cases for setRecordCount()
    @Test
    public void testSetRecordCount_PositiveValue() {
        int value = 20;
        utilproc.setRecordCount(value);
        assertEquals(value, utilproc.getRecordCount());
    }

    @ParameterizedTest(name = "testSetRecordCount_InvalidValue_{index}")
    @CsvSource({
            "-1",
            "100000"
    })
    public void testSetRecordCount_InvalidValue(int value) {
        assertThrows(IllegalArgumentException.class, () -> utilproc.setRecordCount(value));
    }

    // Test case for writeLogRecord()
    @Test
    public void testWriteLogRecord_Message() {
        String message = "This is a log record.";
        // Since the actual implementation of writeLogRecord() is not provided,
        // we'll just verify that it doesn't throw any exceptions.
        utilproc.writeLogRecord(message);
    }
}