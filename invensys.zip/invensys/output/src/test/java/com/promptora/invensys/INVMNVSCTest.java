package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class INVMNVSCTest {

    private INVMNVSC invmnvsc;

    @BeforeEach
    public void setup() {
        invmnvsc = new INVMNVSC();
    }

    // Test getters and setters

    @ParameterizedTest
    @CsvSource({
            "Inventory Management Menu:, Inventory Management Menu:",
            "1. Search Product by ID, 1. Search Product by ID",
            "2. Search Product by Name, 2. Search Product by Name",
            "3. Exit, 3. Exit",
            "Enter Option:, Enter Option:"
    })
    public void testGettersAndSetters(String input, String expected) {
        switch (input) {
            case "Inventory Management Menu:":
                invmnvsc.setMenuHeader(input);
                assertEquals(expected, invmnvsc.getMenuHeader());
                break;
            case "1. Search Product by ID":
                invmnvsc.setSearchProductByID(input);
                assertEquals(expected, invmnvsc.getSearchProductByID());
                break;
            case "2. Search Product by Name":
                invmnvsc.setSearchProductByName(input);
                assertEquals(expected, invmnvsc.getSearchProductByName());
                break;
            case "3. Exit":
                invmnvsc.setExit(input);
                assertEquals(expected, invmnvsc.getExit());
                break;
            case "Enter Option:":
                invmnvsc.setEnterOptionPrompt(input);
                assertEquals(expected, invmnvsc.getEnterOptionPrompt());
                break;
        }
    }

    // Test edge cases for getters and setters

    @Test
    public void testNullInputForGettersAndSetters() {
        assertThrows(NullPointerException.class, () -> invmnvsc.setMenuHeader(null));
        assertThrows(NullPointerException.class, () -> invmnvsc.setSearchProductByID(null));
        assertThrows(NullPointerException.class, () -> invmnvsc.setSearchProductByName(null));
        assertThrows(NullPointerException.class, () -> invmnvsc.setExit(null));
        assertThrows(NullPointerException.class, () -> invmnvsc.setEnterOptionPrompt(null));
    }

    @Test
    public void testEmptyInputForGettersAndSetters() {
        invmnvsc.setMenuHeader("");
        assertEquals("", invmnvsc.getMenuHeader());
        invmnvsc.setSearchProductByID("");
        assertEquals("", invmnvsc.getSearchProductByID());
        invmnvsc.setSearchProductByName("");
        assertEquals("", invmnvsc.getSearchProductByName());
        invmnvsc.setExit("");
        assertEquals("", invmnvsc.getExit());
        invmnvsc.setEnterOptionPrompt("");
        assertEquals("", invmnvsc.getEnterOptionPrompt());
    }

    // Test menu option field

    @Test
    public void testMenuOptionField() {
        char input = '1';
        invmnvsc.setMenuOptionField(input);
        assertEquals(input, invmnvsc.getMenuOptionField());
    }

    @Test
    public void testInvalidInputForMenuOptionField() {
        assertThrows(IllegalArgumentException.class, () -> invmnvsc.setMenuOptionField('a'));
    }
}