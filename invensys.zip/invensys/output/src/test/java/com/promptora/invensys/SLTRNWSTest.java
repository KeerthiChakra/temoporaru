package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class SLTRNWSTest {

    private SLTRNWS sltrnws;

    @BeforeEach
    public void setup() {
        sltrnws = new SLTRNWS();
    }

    // Test cases for set/getProductName
    @Test
    public void testSetGetProductName_NormalCase() {
        String productName = "ProductA";
        sltrnws.setProductName(productName);
        assertEquals(productName, sltrnws.getProductName());
    }

    @ParameterizedTest
    @ValueSource(strings = {"ProductA", "ProductB", "ProductC"})
    public void testSetGetProductName_MultipleProducts(String productName) {
        sltrnws.setProductName(productName);
        assertEquals(productName, sltrnws.getProductName());
    }

    @Test
    public void testSetGetProductName_LongProductName() {
        String longProductName = "This is a very long product name that exceeds 50 characters";
        String truncatedProductName = longProductName.substring(0, Constants.PRODUCT_NAME_MAX_LENGTH);
        sltrnws.setProductName(longProductName);
        assertEquals(truncatedProductName, sltrnws.getProductName());
    }

    // Test cases for set/getQuantitySold
    @Test
    public void testSetGetQuantitySold_NormalCase() {
        int quantitySold = 10;
        sltrnws.setQuantitySold(quantitySold);
        assertEquals(quantitySold, sltrnws.getQuantitySold());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 10, 100})
    public void testSetGetQuantitySold_MultipleQuantities(int quantitySold) {
        sltrnws.setQuantitySold(quantitySold);
        assertEquals(quantitySold, sltrnws.getQuantitySold());
    }

    @Test
    public void testSetGetQuantitySold_MaxValue() {
        int maxQuantitySold = Constants.QUANTITY_SOLD_MAX_VALUE;
        sltrnws.setQuantitySold(maxQuantitySold + 1);
        assertEquals(maxQuantitySold, sltrnws.getQuantitySold());
    }

    // Test cases for set/getSalePrice
    @Test
    public void testSetGetSalePrice_NormalCase() {
        double salePrice = 10.99;
        sltrnws.setSalePrice(salePrice);
        assertEquals(salePrice, sltrnws.getSalePrice(), 0.01); // Use a delta for floating point comparison
    }

    @ParameterizedTest
    @ValueSource(doubles = {1.00, 10.99, 100.99})
    public void testSetGetSalePrice_MultiplePrices(double salePrice) {
        sltrnws.setSalePrice(salePrice);
        assertEquals(salePrice, sltrnws.getSalePrice(), 0.01); // Use a delta for floating point comparison
    }

    @Test
    public void testSetGetSalePrice_MaxValue() {
        double maxSalePrice = Constants.SALE_PRICE_MAX_VALUE;
        sltrnws.setSalePrice(maxSalePrice + 1);
        assertEquals(maxSalePrice, sltrnws.getSalePrice(), 0.01); // Use a delta for floating point comparison
    }

    // Test cases for set/getSaleDate
    @Test
    public void testSetGetSaleDate_NormalCase() {
        long saleDate = System.currentTimeMillis();
        sltrnws.setSaleDate(saleDate);
        assertEquals(saleDate, sltrnws.getSaleDate());
    }

    // Test cases for set/getStoreId
    @Test
    public void testSetGetStoreId_NormalCase() {
        int storeId = 10;
        sltrnws.setStoreId(storeId);
        assertEquals(storeId, sltrnws.getStoreId());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 10, 100})
    public void testSetGetStoreId_MultipleStoreIds(int storeId) {
        sltrnws.setStoreId(storeId);
        assertEquals(storeId, sltrnws.getStoreId());
    }

    @Test
    public void testSetGetStoreId_MaxValue() {
        int maxStoreId = Constants.STORE_ID_MAX_VALUE;
        sltrnws.setStoreId(maxStoreId + 1);
        assertEquals(maxStoreId, sltrnws.getStoreId());
    }
}