package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UPNInventoryFileTest {

    private UPNInventoryFile inventoryFile;

    @BeforeEach
    void setUp() {
        inventoryFile = new UPNInventoryFile();
    }

    // Test product ID getter and setter with valid input
    @ParameterizedTest
    @ValueSource(strings = {"123456789", "abcdefghi"})
    void testSetAndGetProductID(String productId) {
        inventoryFile.setProductID(productId);
        assertEquals(productId, inventoryFile.getProductID());
    }

    // Test product ID validation for null and empty strings
    @Test
    void testSetProductID_NullAndEmpty() {
        assertThrows(IllegalArgumentException.class, () -> inventoryFile.setProductID(null));
        assertThrows(IllegalArgumentException.class, () -> inventoryFile.setProductID(""));
    }

    // Test product ID validation for length exceeding the limit
    @ParameterizedTest
    @ValueSource(strings = {"1234567890", "abcdefghij"})
    void testSetProductID_ExceedingLength(String productId) {
        assertThrows(IllegalArgumentException.class, () -> inventoryFile.setProductID(productId));
    }

    // Test quantity in stock getter and setter with valid input
    @ParameterizedTest
    @ValueSource(ints = {0, 1, 99999})
    void testSetAndGetQuantityInStock(int quantity) {
        inventoryFile.setQuantityInStock(quantity);
        assertEquals(quantity, inventoryFile.getQuantityInStock());
    }

    // Test quantity in stock validation for negative values
    @Test
    void testSetQuantityInStock_Negative() {
        assertThrows(IllegalArgumentException.class, () -> inventoryFile.setQuantityInStock(-1));
    }

    // Test quantity in stock validation for exceeding length limit when converted to string
    @ParameterizedTest
    @ValueSource(ints = {1000000})
    void testSetQuantityInStock_ExceedingLength(int quantity) {
        assertThrows(IllegalArgumentException.class, () -> inventoryFile.setQuantityInStock(quantity));
    }
}