package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class StoreReportFooterTest {

    private StoreReportFooter storeReportFooter;

    @BeforeEach
    public void setup() {
        storeReportFooter = new StoreReportFooter();
    }

    @Test
    public void testDefaultConstructor() {
        assertEquals("End of Report", storeReportFooter.getFooterText());
    }

    @Test
    public void testGetFooterText() {
        String expectedFooterText = "Custom Footer Text";
        storeReportFooter.setFooterText(expectedFooterText);
        assertEquals(expectedFooterText, storeReportFooter.getFooterText());
    }

    @Test
    public void testSetFooterText_NullValue() {
        assertThrows(NullPointerException.class, () -> storeReportFooter.setFooterText(null));
    }

    @Test
    public void testSetFooterText_EmptyString() {
        String expectedFooterText = "";
        storeReportFooter.setFooterText(expectedFooterText);
        assertEquals(expectedFooterText, storeReportFooter.getFooterText());
    }

    @Test
    public void testSetFooterText_WhiteSpaceOnly() {
        String expectedFooterText = "   ";
        storeReportFooter.setFooterText(expectedFooterText);
        assertEquals(expectedFooterText, storeReportFooter.getFooterText());
    }

    @ParameterizedTest
    @ValueSource(strings = {"Hello", "World", "JUnit 5"})
    public void testSetFooterText_CustomValues(String footerText) {
        storeReportFooter.setFooterText(footerText);
        assertEquals(footerText, storeReportFooter.getFooterText());
    }
}