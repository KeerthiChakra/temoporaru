package com.promptora.invsys;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

public class UPNInventoryRecordTest {

    private UPNInventoryFile inventoryFile;

    @BeforeEach
    void setUp() {
        // Initialize test fixture for each test method
        inventoryFile = new UPNInventoryFile();
    }

    @Test
    void testGettersAndSetters_NominalCase() {
        // Create a new instance of UPNInventoryRecord
        UPNInventoryRecord record = new UPNInventoryRecord();

        // Set the inventory file using setter method
        record.setInventoryFile(inventoryFile);

        // Verify that getter returns the same value as set earlier
        assertSame(inventoryFile, record.getInventoryFile());
    }

    @ParameterizedTest
    @NullSource
    void testGettersAndSetters_NullInput(UPNInventoryFile input) {
        // Create a new instance of UPNInventoryRecord
        UPNInventoryRecord record = new UPNInventoryRecord();

        // Set the inventory file using setter method with null input
        record.setInventoryFile(input);

        // Verify that getter returns null as expected
        assertNull(record.getInventoryFile());
    }

    @Test
    void testGettersAndSetters_MultipleSetters() {
        // Create a new instance of UPNInventoryRecord
        UPNInventoryRecord record = new UPNInventoryRecord();

        // Set the inventory file using setter method multiple times with different inputs
        UPNInventoryFile file1 = new UPNInventoryFile();
        record.setInventoryFile(file1);
        assertSame(file1, record.getInventoryFile());

        UPNInventoryFile file2 = new UPNInventoryFile();
        record.setInventoryFile(file2);
        assertSame(file2, record.getInventoryFile());
    }

    @Test
    void testNoArgumentException() {
        // Create a new instance of UPNInventoryRecord without calling setter method
        UPNInventoryRecord record = new UPNInventoryRecord();

        // Verify that no exception is thrown when accessing getter method
        assertDoesNotThrow(() -> record.getInventoryFile());
    }

    @Test
    void testToString() {
        // Create a new instance of UPNInventoryRecord with inventory file set
        UPNInventoryRecord record = new UPNInventoryRecord();
        record.setInventoryFile(inventoryFile);

        // Verify that toString method does not throw an exception
        assertDoesNotThrow(record::toString);
    }
}