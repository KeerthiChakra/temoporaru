
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class SalesTransactionProcessor {
    private SalesTransactionFileReader salesTransactionFileReader;
    private SalesTransactionFileWriter salesTransactionFileWriter;

    public SalesTransactionProcessor() {
        salesTransactionFileReader = new SalesTransactionFileReader();
        salesTransactionFileWriter = new SalesTransactionFileWriter();
    }

    public void processSalesTransactions() {
        // Read sales transactions from file
        SalesTransaction[] salesTransactions = salesTransactionFileReader.readSalesTransactions();

        // Process sales transactions
        for (SalesTransaction salesTransaction : salesTransactions) {
            System.out.println("Processing sales transaction: " + salesTransaction.getTransactionId());
        }

        // Write processed sales transactions to file
        salesTransactionFileWriter.writeSalesTransactions(salesTransactions);
    }
}
