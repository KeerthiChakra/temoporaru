
import java.util.Scanner;

public class InventorySystem {
    private SalesTransactionProcessor salesTransactionProcessor;
    private ProductSearcher productSearcher;
    private InventoryFileReader inventoryFileReader;
    private SalesTransactionFileWriter salesTransactionFileWriter;

    public InventorySystem() {
        salesTransactionProcessor = new SalesTransactionProcessor();
        productSearcher = new ProductSearcher();
        inventoryFileReader = new InventoryFileReader();
        salesTransactionFileWriter = new SalesTransactionFileWriter();
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Inventory Management Menu:");
            System.out.println("1. Search Product by ID");
            System.out.println("2. Search Product by Name");
            System.out.println("3. Exit");
            System.out.print("Enter Option: ");
            String option = scanner.nextLine();
            switch (option) {
                case "1":
                    salesTransactionProcessor.processSalesTransactions();
                    break;
                case "2":
                    productSearcher.searchProductByName();
                    break;
                case "3":
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option");
            }
        }
    }
}
