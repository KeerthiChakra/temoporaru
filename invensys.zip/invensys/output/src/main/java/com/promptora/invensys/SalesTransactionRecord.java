
/**
 * Represents a sales transaction record.
 */
public class SalesTransactionRecord extends InputRecord {
    private String productId;
    private int storeId;
    private int quantitySold;
    private double salePrice;
    private String saleDate;

    /**
     * Constructs an instance of SalesTransactionRecord with default values.
     */
    public SalesTransactionRecord() {}

    /**
     * Gets the product ID.
     *
     * @return the product ID
     */
    public String getProductId() {
        return productId;
    }

    /**
     * Sets the product ID.
     *
     * @param productId the new product ID
     */
    public void setProductId(String productId) {
        this.productId = productId;
    }

    /**
     * Gets the store ID.
     *
     * @return the store ID
     */
    public int getStoreId() {
        return storeId;
    }

    /**
     * Sets the store ID.
     *
     * @param storeId the new store ID
     */
    public void setStoreId(int storeId) {
        this.storeId = storeId;
    }

    /**
     * Gets the quantity sold.
     *
     * @return the quantity sold
     */
    public int getQuantitySold() {
        return quantitySold;
    }

    /**
     * Sets the quantity sold.
     *
     * @param quantitySold the new quantity sold
     */
    public void setQuantitySold(int quantitySold) {
        this.quantitySold = quantitySold;
    }

    /**
     * Gets the sale price.
     *
     * @return the sale price
     */
    public double getSalePrice() {
        return salePrice;
    }

    /**
     * Sets the sale price.
     *
     * @param salePrice the new sale price
     */
    public void setSalePrice(double salePrice) {
        this.salePrice = salePrice;
    }

    /**
     * Gets the sale date.
     *
     * @return the sale date
     */
    public String getSaleDate() {
        return saleDate;
    }

    /**
     * Sets the sale date.
     *
     * @param saleDate the new sale date
     */
    public void setSaleDate(String saleDate) {
        this.saleDate = saleDate;
    }
}
