
/**
 * Original COBOL Code:
 *
 * FileName: INVMNVSC.CPY
 * 
 * 01 INVENTORY-MENU-SCREEN.
 *    05 BLANK SCREEN.
 *    05 VALUE 'Inventory Management Menu:' LINE 3 COL 10.
 *    05 '1. Search Product by ID' LINE 5 COL 10.
 *    05 '2. Search Product by Name' LINE 7 COL 10.
 *    05 '3. Exit' LINE 9 COL 10.
 *    05 'Enter Option:' LINE 11 COL 10.
 *    05 MENU-OPTION-FIELD PIC X LINE 11 COL 24 USING WS-MENU-OPTION.
 */

/**
 * Represents the Inventory Management Menu Screen.
 */
public class INVMNVSC {

    // Constants
    private static final int BLANK_SCREEN_SIZE = 80; // Assuming standard terminal width
    private static final int MENU_OPTION_FIELD_LENGTH = 1;
    private static final String MENU_HEADER = "Inventory Management Menu:";
    private static final String SEARCH_PRODUCT_BY_ID = "1. Search Product by ID";
    private static final String SEARCH_PRODUCT_BY_NAME = "2. Search Product by Name";
    private static final String EXIT = "3. Exit";
    private static final String ENTER_OPTION_PROMPT = "Enter Option:";

    // Fields
    private String menuHeader;
    private String searchProductByID;
    private String searchProductByName;
    private String exit;
    private String enterOptionPrompt;
    private char menuOptionField;

    // Getters and Setters
    public String getMenuHeader() {
        return menuHeader;
    }

    public void setMenuHeader(String menuHeader) {
        this.menuHeader = menuHeader;
    }

    public String getSearchProductByID() {
        return searchProductByID;
    }

    public void setSearchProductByID(String searchProductByID) {
        this.searchProductByID = searchProductByID;
    }

    public String getSearchProductByName() {
        return searchProductByName;
    }

    public void setSearchProductByName(String searchProductByName) {
        this.searchProductByName = searchProductByName;
    }

    public String getExit() {
        return exit;
    }

    public void setExit(String exit) {
        this.exit = exit;
    }

    public String getEnterOptionPrompt() {
        return enterOptionPrompt;
    }

    public void setEnterOptionPrompt(String enterOptionPrompt) {
        this.enterOptionPrompt = enterOptionPrompt;
    }

    public char getMenuOptionField() {
        return menuOptionField;
    }

    public void setMenuOptionField(char menuOptionField) {
        this.menuOptionField = menuOptionField;
    }
}
