
/**
 * SRCHPBN - Search Product By Name
 *
 * Original COBOL code:
 * SEARCH-PRODUCT-BY-NAME.
 * OPEN INPUT INVENTORY-FILE.
 * DISPLAY 'Enter product name to search: ' LINE 5 COL 10.
 * ACCEPT WS-PRODUCT-NAME LINE 5 COL 40.
 * MOVE SPACES TO INVENTORY-RECORD.
 * START INVENTORY-FILE
 *     KEY IS >= PRODUCT-NAME
 *     INVALID KEY
 *         DISPLAY 'Product not found' LINE 20 COL 10
 *         GO TO SEARCH-PRODUCT-BY-NAME-EXIT.
 * READ INVENTORY-FILE NEXT
 */

import java.util.Scanner;

public class SRCHPBN {
    private String wsProductName;
    private InventoryFile inventoryFile;

    public SRCHPBN() {}

    /**
     * Prompts the user to enter a product name and searches for it in the inventory file.
     */
    public void searchProductByName() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter product name to search: ");
        wsProductName = scanner.nextLine();
        // TO DO: implement inventory file operations
    }

    /**
     * Gets the product name entered by the user.
     *
     * @return the product name
     */
    public String getWsProductName() {
        return wsProductName;
    }

    /**
     * Sets the product name entered by the user.
     *
     * @param wsProductName the product name to set
     */
    public void setWsProductName(String wsProductName) {
        this.wsProductName = wsProductName;
    }
}
