
/**
 * Original COBOL Copybook: SQLOPS.CPY
 */

public class SQL_OPS {
    // Constants
    public static final int MAX_SQL_STATEMENT_LENGTH = 100;
    public static final int MAX_ERROR_MESSAGE_LENGTH = 100;

    private String sqlStatement;
    private int sqlCode;
    private String errorMessage;

    /**
     * Constructs a new SQL_OPS object.
     */
    public SQL_OPS() {
        this.sqlStatement = "";
        this.sqlCode = 0;
        this.errorMessage = "";
    }

    // Getters and Setters
    public String getSqlStatement() { return sqlStatement; }
    public void setSqlStatement(String sqlStatement) { this.sqlStatement = sqlStatement; }

    public int getSqlCode() { return sqlCode; }
    public void setSqlCode(int sqlCode) { this.sqlCode = sqlCode; }

    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
}
