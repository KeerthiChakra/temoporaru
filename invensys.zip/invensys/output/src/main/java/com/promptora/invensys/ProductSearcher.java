
import java.util.Scanner;

public class ProductSearcher {
    private InventoryFileReader inventoryFileReader;

    public ProductSearcher() {
        inventoryFileReader = new InventoryFileReader();
    }

    public void searchProductByName() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Product Name to search: ");
        String productName = scanner.nextLine();

        // Search product by name in inventory file
        InventoryRecord[] inventoryRecords = inventoryFileReader.readInventoryRecords();
        for (InventoryRecord inventoryRecord : inventoryRecords) {
            if (inventoryRecord.getProductName().equals(productName)) {
                System.out.println("Product found:");
                System.out.println("Product ID: " + inventoryRecord.getProductId());
                System.out.println("Product Name: " + inventoryRecord.getProductName());
                System.out.println("Product Price: " + inventoryRecord.getProductPrice());
                System.out.println("Product Quantity: " + inventoryRecord.getProductQuantity());
                return;
            }
        }

        System.out.println("Product not found in inventory.");
    }
}
