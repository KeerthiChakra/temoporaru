
/**
 * Original COBOL Copybook:
 * FileName: SLTRNREC.CPY
 *
 * 01 SALES-TRANSACTION-RECORD.
 *     05 TRANSACTION-ID     PIC X(10).
 *     05 PRODUCT-ID         PIC X(10).
 *     05 SALE-QUANTITY      PIC 9(5).
 *     05 SALE-TOTAL         PIC 9(5)V99.
 */

/**
 * Represents a Sales Transaction Record
 */
public class SLTRNREC {
    private String transactionId;
    private String productId;
    private int saleQuantity;
    private BigDecimal saleTotal;

    public static final int TRANSACTION_ID_SIZE = 10;
    public static final int PRODUCT_ID_SIZE = 10;
    public static final int SALE_QUANTITY_SIZE = 5;
    public static final int SALE_TOTAL_SIZE = 7; // includes decimal places

    /**
     * Gets the transaction ID
     *
     * @return the transaction ID
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * Sets the transaction ID
     *
     * @param transactionId the transaction ID to set
     */
    public void setTransactionId(String transactionId) {
        if (transactionId == null || transactionId.length() > TRANSACTION_ID_SIZE) {
            throw new IllegalArgumentException("Invalid transaction ID length");
        }
        this.transactionId = transactionId;
    }

    /**
     * Gets the product ID
     *
     * @return the product ID
     */
    public String getProductId() {
        return productId;
    }

    /**
     * Sets the product ID
     *
     * @param productId the product ID to set
     */
    public void setProductId(String productId) {
        if (productId == null || productId.length() > PRODUCT_ID_SIZE) {
            throw new IllegalArgumentException("Invalid product ID length");
        }
        this.productId = productId;
    }

    /**
     * Gets the sale quantity
     *
     * @return the sale quantity
     */
    public int getSaleQuantity() {
        return saleQuantity;
    }

    /**
     * Sets the sale quantity
     *
     * @param saleQuantity the sale quantity to set
     */
    public void setSaleQuantity(int saleQuantity) {
        if (saleQuantity < 0 || String.valueOf(saleQuantity).length() > SALE_QUANTITY_SIZE) {
            throw new IllegalArgumentException("Invalid sale quantity");
        }
        this.saleQuantity = saleQuantity;
    }

    /**
     * Gets the sale total
     *
     * @return the sale total
     */
    public BigDecimal getSaleTotal() {
        return saleTotal;
    }

    /**
     * Sets the sale total
     *
     * @param saleTotal the sale total to set
     */
    public void setSaleTotal(BigDecimal saleTotal) {
        if (saleTotal == null || saleTotal.toString().length() > SALE_TOTAL_SIZE) {
            throw new IllegalArgumentException("Invalid sale total");
        }
        this.saleTotal = saleTotal;
    }
}
