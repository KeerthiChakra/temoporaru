
/**
 * Original COBOL Copybook: SALES-TRANSACTIONS-TABLE (01 SALES-TRANSACTIONS-TABLE)
 */

public class SalesTransactionsTable {
    // Constants
    public static final int MAX_SALES_TRANSACTION_ID_LENGTH = 5;

    private String salesTransactionId;
    private double amount;
    private Date transactionDate;

    /**
     * Constructs a new SalesTransactionsTable object.
     */
    public SalesTransactionsTable() {
        this.salesTransactionId = "";
        this.amount = 0.0;
        this.transactionDate = null;
    }

    // Getters and Setters
    public String getSalesTransactionId() { return salesTransactionId; }
    public void setSalesTransactionId(String salesTransactionId) { this.salesTransactionId = salesTransactionId; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public Date getTransactionDate() { return transactionDate; }
    public void setTransactionDate(Date transactionDate) { this.transactionDate = transactionDate; }
}
