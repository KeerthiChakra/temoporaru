
public class SalesTransaction {
    private String transactionId;
    private double saleAmount;
    private int quantitySold;

    public SalesTransaction(String transactionId, double saleAmount, int quantitySold) {
        this.transactionId = transactionId;
        this.saleAmount = saleAmount;
        this.quantitySold = quantitySold;
    }

    // Getters and setters
}
