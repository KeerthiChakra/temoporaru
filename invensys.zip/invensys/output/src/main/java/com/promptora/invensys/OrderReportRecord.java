
/**
 * Represents an order report record.
 * 
 * @author [Your Name]
 */
public class OrderReportRecord {
    // Original COBOL code:
    /*
     01 ORDER-REPORT-RECORD.
     05 ORDER-ID PIC 9(5).
     05 PRODUCT-ID PIC 9(5).
     05 ORDER-DATE PIC 9(8).
     05 ORDER-QUANTITY PIC 9(5).
     */

    private static final int MAX_ORDER_ID_LENGTH = 5;
    private static final int MAX_PRODUCT_ID_LENGTH = 5;
    private static final int MAX_ORDER_DATE_LENGTH = 8;
    private static final int MAX_ORDER_QUANTITY_LENGTH = 5;

    private String orderId;
    private String productId;
    private String orderDate;
    private String orderQuantity;

    /**
     * Constructs an empty OrderReportRecord.
     */
    public OrderReportRecord() {}

    /**
     * Gets the order ID.
     * 
     * @return The order ID.
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Sets the order ID.
     * 
     * @param orderId The new order ID. Must be no longer than MAX_ORDER_ID_LENGTH.
     */
    public void setOrderId(String orderId) {
        if (orderId.length() > MAX_ORDER_ID_LENGTH) {
            throw new IllegalArgumentException("Order ID too long");
        }
        this.orderId = orderId;
    }

    /**
     * Gets the product ID.
     * 
     * @return The product ID.
     */
    public String getProductId() {
        return productId;
    }

    /**
     * Sets the product ID.
     * 
     * @param productId The new product ID. Must be no longer than MAX_PRODUCT_ID_LENGTH.
     */
    public void setProductId(String productId) {
        if (productId.length() > MAX_PRODUCT_ID_LENGTH) {
            throw new IllegalArgumentException("Product ID too long");
        }
        this.productId = productId;
    }

    /**
     * Gets the order date.
     * 
     * @return The order date.
     */
    public String getOrderDate() {
        return orderDate;
    }

    /**
     * Sets the order date.
     * 
     * @param orderDate The new order date. Must be no longer than MAX_ORDER_DATE_LENGTH.
     */
    public void setOrderDate(String orderDate) {
        if (orderDate.length() > MAX_ORDER_DATE_LENGTH) {
            throw new IllegalArgumentException("Order date too long");
        }
        this.orderDate = orderDate;
    }

    /**
     * Gets the order quantity.
     * 
     * @return The order quantity.
     */
    public String getOrderQuantity() {
        return orderQuantity;
    }

    /**
     * Sets the order quantity.
     * 
     * @param orderQuantity The new order quantity. Must be no longer than MAX_ORDER_QUANTITY_LENGTH.
     */
    public void setOrderQuantity(String orderQuantity) {
        if (orderQuantity.length() > MAX_ORDER_QUANTITY_LENGTH) {
            throw new IllegalArgumentException("Order quantity too long");
        }
        this.orderQuantity = orderQuantity;
    }

    @Override
    public String toString() {
        return "OrderReportRecord{" +
                "orderId='" + orderId + '\'' +
                ", productId='" + productId + '\'' +
                ", orderDate='" + orderDate + '\'' +
                ", orderQuantity='" + orderQuantity + '\'' +
                '}';
    }
}
