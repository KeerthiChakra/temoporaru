
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DailySalesReport {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/sales";
    private static final String USER = "root";
    private static final String PASS = "password";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            Statement stmt = conn.createStatement();
            ResultSet rs;

            // Get current date
            Date currentDate = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String dateString = dateFormat.format(currentDate);

            // Generate daily sales report
            String query = "SELECT s.StoreID, s.StoreName, SUM(st.Quantity) AS TotalQuantitySold, "
                    + "SUM(st.SalePrice * st.Quantity) AS TotalSalesAmount "
                    + "FROM SalesTransactions st JOIN Stores s ON st.StoreID = s.StoreID "
                    + "WHERE st.SaleDate = '" + dateString + "' GROUP BY s.StoreID, s.StoreName";

            rs = stmt.executeQuery(query);

            // Print report header
            System.out.println("Daily Sales Report");
            System.out.println("--------------------");

            // Print report records
            while (rs.next()) {
                int storeId = rs.getInt(1);
                String storeName = rs.getString(2);
                double totalQuantitySold = rs.getDouble(3);
                double totalSalesAmount = rs.getDouble(4);

                System.out.println(storeId + "\t" + storeName + "\t" + totalQuantitySold + "\t" + totalSalesAmount);
            }

            // Print report footer
            System.out.println("--------------------");
            System.out.println("End of Report");

        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}
