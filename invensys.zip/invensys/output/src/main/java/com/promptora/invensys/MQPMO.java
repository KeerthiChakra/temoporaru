
/**
 * MQPMO (Message Queue Put Message Options)
 *
 * Original COBOL code:
 * <pre>
 *     01 MQPMO.
 *         05 MQPMO-VERSION            PIC 9(4) COMP VALUE 1.
 *         05 MQPMO-OPTIONS            PIC 9(9) COMP VALUE 0.
 * </pre>
 */
public class MQPMO {
    private int version;
    private long options;

    public static final int VERSION_DEFAULT = 1;

    /**
     * Constructor with default values
     */
    public MQPMO() {
        this.version = VERSION_DEFAULT;
        this.options = 0L;
    }

    /**
     * Getters and setters
     */
    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        if (version < 0) {
            throw new IllegalArgumentException("Invalid version");
        }
        this.version = version;
    }

    public long getOptions() {
        return options;
    }

    public void setOptions(long options) {
        if (options < 0) {
            throw new IllegalArgumentException("Invalid options");
        }
        this.options = options;
    }
}
