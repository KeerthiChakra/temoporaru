
/**
 * Represents the header of a store report.
 *
 * @author [Your Name]
 */
public class StoreReportHeader {
    /**
     * The title of the report.
     */
    private String headerTitle;

    /**
     * The date of the report.
     */
    private String headerDate;

    /**
     * Creates a new instance with default values.
     */
    public StoreReportHeader() {
        this.headerTitle = "Daily Sales Report";
        this.headerDate = "";
    }

    /**
     * Gets the title of the report.
     *
     * @return The title of the report.
     */
    public String getHeaderTitle() {
        return headerTitle;
    }

    /**
     * Sets the title of the report.
     *
     * @param headerTitle The new title of the report.
     */
    public void setHeaderTitle(String headerTitle) {
        this.headerTitle = headerTitle;
    }

    /**
     * Gets the date of the report.
     *
     * @return The date of the report.
     */
    public String getHeaderDate() {
        return headerDate;
    }

    /**
     * Sets the date of the report.
     *
     * @param headerDate The new date of the report.
     */
    public void setHeaderDate(String headerDate) {
        this.headerDate = headerDate;
    }
}
