
/**
 * MQMD (Message Queue Message Descriptor)
 *
 * Original COBOL code:
 * <pre>
 *     01 MQMD.
 *         05 MQMD-FORMAT              PIC X(8) VALUE '        '.
 *         05 MQMD-VERSION             PIC 9(4) COMP VALUE 2.
 *         05 MQMD-MSGID               PIC X(24) VALUE '        '.
 *         05 MQMD-CORRELID            PIC X(24) VALUE '        '.
 *         05 MQMD-PERSISTENCE         PIC 9(4) COMP VALUE 1.
 *         05 MQMD-PUTTIME             PIC X(8) VALUE '        '.
 *         05 MQMD-PUTDATE             PIC X(8) VALUE '        '.
 * </pre>
 */
public class MQMD {
    private String format;
    private int version;
    private String msgId;
    private String correlId;
    private int persistence;
    private String putTime;
    private String putDate;

    public static final int FORMAT_LENGTH = 8;
    public static final int VERSION_DEFAULT = 2;
    public static final int MSGID_LENGTH = 24;
    public static final int CORRELID_LENGTH = 24;
    public static final int PERSISTENCE_DEFAULT = 1;
    public static final int PUTTIME_LENGTH = 8;
    public static final int PUTDATE_LENGTH = 8;

    /**
     * Constructor with default values
     */
    public MQMD() {
        this.format = "";
        this.version = VERSION_DEFAULT;
        this.msgId = "";
        this.correlId = "";
        this.persistence = PERSISTENCE_DEFAULT;
        this.putTime = "";
        this.putDate = "";
    }

    /**
     * Getters and setters
     */
    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        if (format == null || format.length() > FORMAT_LENGTH) {
            throw new IllegalArgumentException("Invalid format length");
        }
        this.format = format;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        if (version < 0) {
            throw new IllegalArgumentException("Invalid version");
        }
        this.version = version;
    }

    // ... other getters and setters ...
}
