
/**
 * Represents an inventory order record.
 */
public class InventoryOrderRecord extends InputRecord {
    private String productId;
    private int storeId;
    private int orderQuantity;

    /**
     * Constructs an instance of InventoryOrderRecord with default values.
     */
    public InventoryOrderRecord() {}

    /**
     * Gets the product ID.
     *
     * @return the product ID
     */
    public String getProductId() {
        return productId;
    }

    /**
     * Sets the product ID.
     *
     * @param productId the new product ID
     */
    public void setProductId(String productId) {
        this.productId = productId;
    }

    /**
     * Gets the store ID.
     *
     * @return the store ID
     */
    public int getStoreId() {
        return storeId;
    }

    /**
     * Sets the store ID.
     *
     * @param storeId the new store ID
     */
    public void setStoreId(int storeId) {
        this.storeId = storeId;
    }

    /**
     * Gets the order quantity.
     *
     * @return the order quantity
     */
    public int getOrderQuantity() {
        return orderQuantity;
    }

    /**
     * Sets the order quantity.
     *
     * @param orderQuantity the new order quantity
     */
    public void setOrderQuantity(int orderQuantity) {
        this.orderQuantity = orderQuantity;
    }
}
