
/**
 * Represents the footer of a store report.
 *
 * @author [Your Name]
 */
public class StoreReportFooter {
    /**
     * The text of the footer.
     */
    private String footerText;

    /**
     * Creates a new instance with default values.
     */
    public StoreReportFooter() {
        this.footerText = "End of Report";
    }

    /**
     * Gets the text of the footer.
     *
     * @return The text of the footer.
     */
    public String getFooterText() {
        return footerText;
    }

    /**
     * Sets the text of the footer.
     *
     * @param footerText The new text of the footer.
     */
    public void setFooterText(String footerText) {
        this.footerText = footerText;
    }
}
