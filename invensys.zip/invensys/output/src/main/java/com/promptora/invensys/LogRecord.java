
/**
 * Represents a log record.
 */
public class LogRecord {
    private String logData;

    /**
     * Constructs an instance of LogRecord with default values.
     */
    public LogRecord() {}

    /**
     * Gets the log data.
     *
     * @return the log data
     */
    public String getLogData() {
        return logData;
    }

    /**
     * Sets the log data.
     *
     * @param logData the new log data
     */
    public void setLogData(String logData) {
        this.logData = logData;
    }
}
