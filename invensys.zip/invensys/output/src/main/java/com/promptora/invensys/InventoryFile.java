
/**
 * InventoryFile - represents an inventory file with records.
 *
 * Original COBOL code:
 * INVENTORY-FILE.
 */

import java.util.ArrayList;

public class InventoryFile {
    private ArrayList<InventoryRecord> records;

    public InventoryFile() {
        this.records = new ArrayList<>();
    }

    /**
     * Adds a record to the inventory file.
     *
     * @param record the record to add
     */
    public void addRecord(InventoryRecord record) {
        this.records.add(record);
    }

    /**
     * Gets the records in the inventory file.
     *
     * @return the records
     */
    public ArrayList<InventoryRecord> getRecords() {
        return this.records;
    }
}
