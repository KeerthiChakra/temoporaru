
/*
 * Original COBOL Code:
 *
 * FileName: INVMNUWS.CPY
 * 
 * 01 WS-MENU-OPTION       PIC X.
 */

/**
 * Represents a single menu option.
 */
public class INVMNUWS {

    /**
     * Universal constant for the size limit of the menu option field.
     */
    public static final int MENU_OPTION_SIZE = 1;

    /**
     * The menu option value.
     */
    private String menuOption;

    /**
     * Constructs an instance with a default empty string as the menu option value.
     */
    public INVMNUWS() {
        this.menuOption = "";
    }

    /**
     * Gets the menu option value.
     *
     * @return The menu option value, never null.
     */
    public String getMenuOption() {
        return menuOption;
    }

    /**
     * Sets the menu option value. Trims and limits to {@link #MENU_OPTION_SIZE} characters.
     *
     * @param menuOption The new menu option value, not null.
     */
    public void setMenuOption(String menuOption) {
        if (menuOption != null) {
            this.menuOption = menuOption.trim().substring(0, Math.min(menuOption.length(), MENU_OPTION_SIZE));
        }
    }

}
