
/**
 * Inserts a new sales transaction into the database.
 */

public class InsertSalesTransaction {
    private SQL_OPS sqlOps;
    private SalesTransactionsTable salesTransaction;

    /**
     * Constructs a new InsertSalesTransaction object.
     */
    public InsertSalesTransaction(SQL_OPS sqlOps, SalesTransactionsTable salesTransaction) {
        this.sqlOps = sqlOps;
        this.salesTransaction = salesTransaction;
    }

    /**
     * Inserts the sales transaction into the database.
     */
    public void insert() {
        // Prepare SQL statement
        String sqlStatement = "INSERT INTO SALES_TRANSACTIONS (ID, AMOUNT, TRANSACTION_DATE) VALUES (?, ?, ?)";
        sqlOps.setSqlStatement(sqlStatement);

        // Bind parameters
        PreparedStatement pstmt = null;
        try {
            pstmt = connection.prepareStatement(sqlOps.getSqlStatement());
            pstmt.setString(1, salesTransaction.getSalesTransactionId());
            pstmt.setDouble(2, salesTransaction.getAmount());
            pstmt.setDate(3, salesTransaction.getTransactionDate());

            // Execute SQL statement
            pstmt.executeUpdate();

            // Commit transaction
            connection.commit();
        } catch (SQLException e) {
            // Rollback transaction on error
            if (connection != null) {
                try {
                    connection.rollback();
                } catch (SQLException ex) {
                    Logger.getLogger(InsertSalesTransaction.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            // Log error message
            sqlOps.setErrorMessage(e.getMessage());
        } finally {
            // Close prepared statement and connection
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    Logger.getLogger(InsertSalesTransaction.class.getName()).log(Level.SEVERE, null, e);
                }
            }

            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException ex) {
                    Logger.getLogger(InsertSalesTransaction.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
}
