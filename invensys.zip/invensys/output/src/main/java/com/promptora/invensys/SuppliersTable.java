
/**
 * Original COBOL Copybook: SUPPLIERS-TABLE (01 SUPPLIERS-TABLE)
 */

public class SuppliersTable {
    // Constants
    public static final int MAX_SUPPLIER_ID_LENGTH = 5;
    public static final int MAX_SUPPLIER_NAME_LENGTH = 255;

    private String supplierId;
    private String supplierName;
    private String supplierAddress;
    private String supplierPhone;
    private String supplierEmail;

    /**
     * Constructs a new SuppliersTable object.
     */
    public SuppliersTable() {
        this.supplierId = "";
        this.supplierName = "";
        this.supplierAddress = "";
        this.supplierPhone = "";
        this.supplierEmail = "";
    }

    // Getters and Setters
    public String getSupplierId() { return supplierId; }
    public void setSupplierId(String supplierId) { this.supplierId = supplierId; }

    public String getSupplierName() { return supplierName; }
    public void setSupplierName(String supplierName) { this.supplierName = supplierName; }

    public String getSupplierAddress() { return supplierAddress; }
    public void setSupplierAddress(String supplierAddress) { this.supplierAddress = supplierAddress; }

    public String getSupplierPhone() { return supplierPhone; }
    public void setSupplierPhone(String supplierPhone) { this.supplierPhone = supplierPhone; }

    public String getSupplierEmail() { return supplierEmail; }
    public void setSupplierEmail(String supplierEmail) { this.supplierEmail = supplierEmail; }
}
