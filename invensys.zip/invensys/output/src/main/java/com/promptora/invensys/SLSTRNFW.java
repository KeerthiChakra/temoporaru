
/**
 * SLSTRNFW class represents a sales transaction record.
 *
 * Original COBOL Copybook:
 * FileName: SLSTRNFW.CPY
 * WRITE-SALES-TRANSACTION-FILE.
 * OPEN OUTPUT SALES-TRANSACTIONS-FILE.
 * MOVE PRODUCT-ID TO PRODUCT-ID.
 * MOVE QUANTITY-SOLD TO QUANTITY-SOLD.
 * MOVE SALE-PRICE TO SALE-PRICE.
 * MOVE SALE-DATE TO SALE-DATE.
 * MOVE STORE-ID TO STORE-ID.
 * WRITE SALES-TRANSACTION-RECORD.
 * CLOSE SALES-TRANSACTIONS-FILE.
 */

public class SLSTRNFW {
    private String productID;
    private int quantitySold;
    private double salePrice;
    private String saleDate;
    private String storeID;

    public SLSTRNFW() {}

    /**
     * Gets the product ID.
     *
     * @return the product ID
     */
    public String getProductID() {
        return productID;
    }

    /**
     * Sets the product ID.
     *
     * @param productID the new product ID
     */
    public void setProductID(String productID) {
        this.productID = productID;
    }

    /**
     * Gets the quantity sold.
     *
     * @return the quantity sold
     */
    public int getQuantitySold() {
        return quantitySold;
    }

    /**
     * Sets the quantity sold.
     *
     * @param quantitySold the new quantity sold
     */
    public void setQuantitySold(int quantitySold) {
        this.quantitySold = quantitySold;
    }

    /**
     * Gets the sale price.
     *
     * @return the sale price
     */
    public double getSalePrice() {
        return salePrice;
    }

    /**
     * Sets the sale price.
     *
     * @param salePrice the new sale price
     */
    public void setSalePrice(double salePrice) {
        this.salePrice = salePrice;
    }

    /**
     * Gets the sale date.
     *
     * @return the sale date
     */
    public String getSaleDate() {
        return saleDate;
    }

    /**
     * Sets the sale date.
     *
     * @param saleDate the new sale date
     */
    public void setSaleDate(String saleDate) {
        this.saleDate = saleDate;
    }

    /**
     * Gets the store ID.
     *
     * @return the store ID
     */
    public String getStoreID() {
        return storeID;
    }

    /**
     * Sets the store ID.
     *
     * @param storeID the new store ID
     */
    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }
}
