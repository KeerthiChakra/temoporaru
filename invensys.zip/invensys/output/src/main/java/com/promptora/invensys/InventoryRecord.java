
public class InventoryRecord {
    private String productId;
    private String productName;
    private double productPrice;
    private int productQuantity;

    public InventoryRecord(String productId, String productName, double productPrice, int productQuantity) {
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productQuantity = productQuantity;
    }

    // Getters and setters
}
