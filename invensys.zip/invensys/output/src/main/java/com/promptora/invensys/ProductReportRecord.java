
/**
 * Represents a product report record.
 *
 * @author [Your Name]
 */
public class ProductReportRecord {
    // Original COBOL code:
    /*FileName: PRDRPT.CPY
    01 PRODUCT-REPORT-RECORD.
        05 PRODUCT-ID PIC 9(5).
        05 PRODUCT-NAME PIC X(20).
        05 SALE-DATE PIC 9(8).
        05 SALE-AMOUNT PIC 9(10)V9(2).*/

    // Constants
    public static final int PRODUCT_ID_SIZE = 5;
    public static final int PRODUCT_NAME_SIZE = 20;
    public static final int SALE_DATE_SIZE = 8;
    public static final int SALE_AMOUNT_SIZE = 12; // 10 digits + 2 decimal places

    private String productId;
    private String productName;
    private String saleDate;
    private BigDecimal saleAmount;

    /**
     * Constructs a new ProductReportRecord.
     */
    public ProductReportRecord() {}

    /**
     * Gets the product ID.
     *
     * @return The product ID.
     */
    public String getProductId() {
        return productId;
    }

    /**
     * Sets the product ID.
     *
     * @param productId The new product ID. Must be a string of length 5 or less.
     */
    public void setProductId(String productId) {
        if (productId.length() > PRODUCT_ID_SIZE) {
            throw new IllegalArgumentException("Product ID must be 5 characters or less");
        }
        this.productId = productId;
    }

    /**
     * Gets the product name.
     *
     * @return The product name.
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets the product name.
     *
     * @param productName The new product name. Must be a string of length 20 or less.
     */
    public void setProductName(String productName) {
        if (productName.length() > PRODUCT_NAME_SIZE) {
            throw new IllegalArgumentException("Product name must be 20 characters or less");
        }
        this.productName = productName;
    }

    /**
     * Gets the sale date.
     *
     * @return The sale date.
     */
    public String getSaleDate() {
        return saleDate;
    }

    /**
     * Sets the sale date.
     *
     * @param saleDate The new sale date. Must be a string of length 8 or less.
     */
    public void setSaleDate(String saleDate) {
        if (saleDate.length() > SALE_DATE_SIZE) {
            throw new IllegalArgumentException("Sale date must be 8 characters or less");
        }
        this.saleDate = saleDate;
    }

    /**
     * Gets the sale amount.
     *
     * @return The sale amount.
     */
    public BigDecimal getSaleAmount() {
        return saleAmount;
    }

    /**
     * Sets the sale amount.
     *
     * @param saleAmount The new sale amount. Must be a valid decimal value with 2 or fewer decimal places.
     */
    public void setSaleAmount(BigDecimal saleAmount) {
        if (saleAmount.scale() > 2) {
            throw new IllegalArgumentException("Sale amount must have 2 or fewer decimal places");
        }
        this.saleAmount = saleAmount;
    }
}
