
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

public class SalesTransactionFileReader {
    public SalesTransaction[] readSalesTransactions() {
        // Read sales transactions from file
        ArrayList<SalesTransaction> salesTransactions = new ArrayList<>();
        File file = new File("sales_transactions.txt");
        try (FileReader fileReader = new FileReader(file)) {
            String line;
            while ((line = fileReader.readLine()) != null) {
                String[] fields = line.split(",");
                SalesTransaction salesTransaction = new SalesTransaction(fields[0], Double.parseDouble(fields[1]), Integer.parseInt(fields[2]));
                salesTransactions.add(salesTransaction);
            }
        } catch (IOException e) {
            System.out.println("Error reading sales transactions file: " + e.getMessage());
        }

        return salesTransactions.toArray(new SalesTransaction[0]);
    }
}
