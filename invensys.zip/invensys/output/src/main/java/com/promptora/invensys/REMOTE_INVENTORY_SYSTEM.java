
public class REMOTE_INVENTORY_SYSTEM {
    public static void main(String[] args) {
        InventorySystem inventorySystem = new InventorySystem();
        inventorySystem.run();
    }
}
