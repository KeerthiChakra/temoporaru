
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

public class InventoryFileReader {
    public InventoryRecord[] readInventoryRecords() {
        // Read inventory records from file
        ArrayList<InventoryRecord> inventoryRecords = new ArrayList<>();
        File file = new File("inventory.txt");
        try (FileReader fileReader = new FileReader(file)) {
            String line;
            while ((line = fileReader.readLine()) != null) {
                String[] fields = line.split(",");
                InventoryRecord inventoryRecord = new InventoryRecord(fields[0], fields[1], Double.parseDouble(fields[2]), Integer.parseInt(fields[3]));
                inventoryRecords.add(inventoryRecord);
            }
        } catch (IOException e) {
            System.out.println("Error reading inventory file: " + e.getMessage());
        }

        return inventoryRecords.toArray(new InventoryRecord[0]);
    }
}
