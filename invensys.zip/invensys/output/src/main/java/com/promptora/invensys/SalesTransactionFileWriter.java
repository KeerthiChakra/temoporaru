
import java.io.FileWriter;
import java.io.IOException;

public class SalesTransactionFileWriter {
    public void writeSalesTransactions(SalesTransaction[] salesTransactions) {
        // Write processed sales transactions to file
        try (FileWriter fileWriter = new FileWriter("sales_transactions.txt")) {
            for (SalesTransaction salesTransaction : salesTransactions) {
                fileWriter.write(salesTransaction.getTransactionId() + "," + salesTransaction.getSaleAmount() + "," + salesTransaction.getQuantitySold() + "\n");
            }
        } catch (IOException e) {
            System.out.println("Error writing to sales transactions file: " + e.getMessage());
        }
    }
}
