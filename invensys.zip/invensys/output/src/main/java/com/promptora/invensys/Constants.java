
/**
 * Universal constants for size limits and other fixed values.
 */
public class Constants {
    /**
     * Maximum length of the product name (50 characters).
     */
    public static final int PRODUCT_NAME_MAX_LENGTH = 50;

    /**
     * Maximum value of the quantity sold (4 digits).
     */
    public static final int QUANTITY_SOLD_MAX_VALUE = 9999;

    /**
     * Maximum value of the sale price (6 digits + 2 decimal places).
     */
    public static final double SALE_PRICE_MAX_VALUE = 999999.99;

    /**
     * Maximum value of the store ID (4 digits).
     */
    public static final int STORE_ID_MAX_VALUE = 9999;
}
