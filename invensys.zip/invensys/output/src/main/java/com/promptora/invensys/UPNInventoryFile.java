
/**
 * Represents the inventory file record structure as defined in the UPNINVFL.CPY COBOL copybook.
 */
public class UPNInventoryFile {
    // Original COBOL code as a block comment for reference
    /**
     * UPDATE-INVENTORY-FILE.
     * OPEN I-O INVENTORY-FILE.
     * READ INVENTORY-FILE
     *     INTO INVENTORY-RECORD
     *     KEY IS PRODUCT-ID
     *     INVALID KEY
     *         DISPLAY 'Product not found in inventory' LINE 20 COL 10
     *         GO TO UPDATE-INVENTORY-FILE-EXIT.
     * SUBTRACT QUANTITY-SOLD FROM QUANTITY-IN-STOCK.
     * REWRITE INVENTORY-RECORD.
     * UPDATE-INVENTORY-FILE-EXIT.
     * CLOSE INVENTORY-FILE.
     */

    // Constants for size limits and other fixed values
    public static final int PRODUCT_ID_SIZE = 10;
    public static final int QUANTITY_IN_STOCK_SIZE = 5;

    private String productID;
    private int quantityInStock;

    // Getters and setters
    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        if (productID == null || productID.length() > PRODUCT_ID_SIZE) {
            throw new IllegalArgumentException("Invalid product ID");
        }
        this.productID = productID;
    }

    public int getQuantityInStock() {
        return quantityInStock;
    }

    public void setQuantityInStock(int quantityInStock) {
        if (quantityInStock < 0 || String.valueOf(quantityInStock).length() > QUANTITY_IN_STOCK_SIZE) {
            throw new IllegalArgumentException("Invalid quantity in stock");
        }
        this.quantityInStock = quantityInStock;
    }
}
