
/**
 * Original COBOL Copybook:
 * FileName: INVREC.CPY
 * 
 * 01 INVENTORY-RECORD.
 *     05 PRODUCT-ID         PIC X(10).
 *     05 PRODUCT-NAME       PIC X(50).
 *     05 PRODUCT-PRICE      PIC 9(5)V99. 
 *     05 PRODUCT-QUANTITY    PIC 9(5).
 */

/**
 * Represents an inventory record.
 */
public class INVREC {
    private String productId;
    private String productName;
    private BigDecimal productPrice;
    private int productQuantity;

    /**
     * Constructs a new inventory record with default values.
     */
    public INVREC() {}

    /**
     * Constructs a new inventory record with the given fields.
     * 
     * @param productId        Product ID
     * @param productName      Product name
     * @param productPrice     Product price
     * @param productQuantity  Product quantity
     */
    public INVREC(String productId, String productName, BigDecimal productPrice, int productQuantity) {
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productQuantity = productQuantity;
    }

    /**
     * Gets the product ID.
     * 
     * @return Product ID
     */
    public String getProductId() {
        return productId;
    }

    /**
     * Sets the product ID.
     * 
     * @param productId  New product ID
     */
    public void setProductId(String productId) {
        this.productId = productId;
    }

    /**
     * Gets the product name.
     * 
     * @return Product name
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets the product name.
     * 
     * @param productName  New product name
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * Gets the product price.
     * 
     * @return Product price
     */
    public BigDecimal getProductPrice() {
        return productPrice;
    }

    /**
     * Sets the product price.
     * 
     * @param productPrice  New product price
     */
    public void setProductPrice(BigDecimal productPrice) {
        this.productPrice = productPrice;
    }

    /**
     * Gets the product quantity.
     * 
     * @return Product quantity
     */
    public int getProductQuantity() {
        return productQuantity;
    }

    /**
     * Sets the product quantity.
     * 
     * @param productQuantity  New product quantity
     */
    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }
}
