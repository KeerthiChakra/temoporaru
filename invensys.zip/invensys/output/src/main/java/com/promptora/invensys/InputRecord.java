
/**
 * Represents an input record.
 */
public class InputRecord {
    private String recordType;
    private String recordData;

    /**
     * Constructs an instance of InputRecord with default values.
     */
    public InputRecord() {}

    /**
     * Gets the record type.
     *
     * @return the record type
     */
    public String getRecordType() {
        return recordType;
    }

    /**
     * Sets the record type.
     *
     * @param recordType the new record type
     */
    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    /**
     * Gets the record data.
     *
     * @return the record data
     */
    public String getRecordData() {
        return recordData;
    }

    /**
     * Sets the record data.
     *
     * @param recordData the new record data
     */
    public void setRecordData(String recordData) {
        this.recordData = recordData;
    }
}
