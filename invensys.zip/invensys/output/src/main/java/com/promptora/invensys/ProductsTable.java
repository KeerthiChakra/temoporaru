
/**
 * Original COBOL Copybook: PRODUCTS-TABLE (01 PRODUCTS-TABLE)
 */

public class ProductsTable {
    // Constants
    public static final int MAX_PRODUCT_ID_LENGTH = 5;
    public static final int MAX_PRODUCT_NAME_LENGTH = 255;
    public static final int MAX_PRODUCT_DESCRIPTION_LENGTH = 1000;

    private String productId;
    private String productName;
    private String productDescription;
    private double unitPrice;
    private int quantityInStock;
    private int reorderLevel;
    private int supplierId;

    /**
     * Constructs a new ProductsTable object.
     */
    public ProductsTable() {
        this.productId = "";
        this.productName = "";
        this.productDescription = "";
        this.unitPrice = 0.0;
        this.quantityInStock = 0;
        this.reorderLevel = 0;
        this.supplierId = 0;
    }

    // Getters and Setters
    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public String getProductDescription() { return productDescription; }
    public void setProductDescription(String productDescription) { this.productDescription = productDescription; }

    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }

    public int getQuantityInStock() { return quantityInStock; }
    public void setQuantityInStock(int quantityInStock) { this.quantityInStock = quantityInStock; }

    public int getReorderLevel() { return reorderLevel; }
    public void setReorderLevel(int reorderLevel) { this.reorderLevel = reorderLevel; }

    public int getSupplierId() { return supplierId; }
    public void setSupplierId(int supplierId) { this.supplierId = supplierId; }
}
