
/**
 * Original COBOL Copybook:
 *
 * FileName: DLYREC.CPY
 * 01 DAILY-RECORD.
 *   05 RECORD-TYPE PIC X(1).
 *   05 RECORD-DATA PIC X(200).
 */
public class DLYREC {
    private String recordType;
    private String recordData;

    public static final int RECORD_TYPE_SIZE = 1;
    public static final int RECORD_DATA_SIZE = 200;

    /**
     * Constructor
     */
    public DLYREC() {}

    /**
     * Gets the record type.
     *
     * @return the record type
     */
    public String getRecordType() {
        return recordType;
    }

    /**
     * Sets the record type.
     *
     * @param recordType the new record type
     */
    public void setRecordType(String recordType) {
        if (recordType.length() > RECORD_TYPE_SIZE) {
            throw new IllegalArgumentException("Record type exceeds maximum length of " + RECORD_TYPE_SIZE);
        }
        this.recordType = recordType;
    }

    /**
     * Gets the record data.
     *
     * @return the record data
     */
    public String getRecordData() {
        return recordData;
    }

    /**
     * Sets the record data.
     *
     * @param recordData the new record data
     */
    public void setRecordData(String recordData) {
        if (recordData.length() > RECORD_DATA_SIZE) {
            throw new IllegalArgumentException("Record data exceeds maximum length of " + RECORD_DATA_SIZE);
        }
        this.recordData = recordData;
    }

    /**
     * Returns a string representation of the DLYREC object.
     *
     * @return a string representation of the DLYREC object
     */
    @Override
    public String toString() {
        return "DLYREC{" +
                "recordType='" + recordType + '\'' +
                ", recordData='" + recordData + '\'' +
                '}';
    }
}
