
/**
 * Represents a record in a store report.
 *
 * @author [Your Name]
 */
public class StoreReportRecord {
    /**
     * The ID of the store.
     */
    private int storeId;

    /**
     * The name of the store.
     */
    private String storeName;

    /**
     * The date of the sale.
     */
    private String saleDate;

    /**
     * The amount of the sale.
     */
    private double saleAmount;

    /**
     * Creates a new instance with default values.
     */
    public StoreReportRecord() {
        this.storeId = 0;
        this.storeName = "";
        this.saleDate = "";
        this.saleAmount = 0.00;
    }

    /**
     * Gets the ID of the store.
     *
     * @return The ID of the store.
     */
    public int getStoreId() {
        return storeId;
    }

    /**
     * Sets the ID of the store.
     *
     * @param storeId The new ID of the store.
     */
    public void setStoreId(int storeId) {
        this.storeId = storeId;
    }

    /**
     * Gets the name of the store.
     *
     * @return The name of the store.
     */
    public String getStoreName() {
        return storeName;
    }

    /**
     * Sets the name of the store.
     *
     * @param storeName The new name of the store.
     */
    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    /**
     * Gets the date of the sale.
     *
     * @return The date of the sale.
     */
    public String getSaleDate() {
        return saleDate;
    }

    /**
     * Sets the date of the sale.
     *
     * @param saleDate The new date of the sale.
     */
    public void setSaleDate(String saleDate) {
        this.saleDate = saleDate;
    }

    /**
     * Gets the amount of the sale.
     *
     * @return The amount of the sale.
     */
    public double getSaleAmount() {
        return saleAmount;
    }

    /**
     * Sets the amount of the sale.
     *
     * @param saleAmount The new amount of the sale.
     */
    public void setSaleAmount(double saleAmount) {
        this.saleAmount = saleAmount;
    }
}
