
// SalesTransactionScreen.java

/**
 * Represents a sales transaction screen.
 *
 * @author [Your Name]
 */
public class SalesTransactionScreen {
    // Original COBOL code as a block comment for reference
    /* 
        01 SALES-TRANSACTION-SCREEN.
         05 BLANK SCREEN.
         05 VALUE 'Enter Sales Transaction:' LINE 3 COL 10.
         05 'Product Name:' LINE 5 COL 10.
         05 PRODUCT-NAME-
         05 PRODUCT-NAME-FIELD PIC X(50) LINE 5 COL 20 USING WS-PRODUCT-NAME.
         05 'Quantity Sold:' LINE 7 COL 10.
         05 QUANTITY-SOLD-FIELD PIC 9(4) LINE 7 COL 20 USING WS-QUANTITY-SOLD.
         05 'Sale Price:' LINE 9 COL 10.
         05 SALE-PRICE-FIELD PIC 9(6)V99 LINE 9 COL 20 USING WS-SALE-PRICE.
         05 'Sale Date:' LINE 11 COL 10.
         05 SALE-DATE-FIELD PIC 9(8) LINE 11 COL 20 USING WS-SALE-DATE.
         05 'Store ID:' LINE 13 COL 10.
         05 STORE-ID-FIELD PIC 9(4) LINE 13 COL 20 USING WS-STORE-ID.
         05 'Enter' LINE 15 COL 10 PIC X(5) USING WS-ENTER.
         05 'Cancel' LINE 15 COL 20 PIC X(6) USING WS-CANCEL.
    */

    // Constants for size limits
    private static final int PRODUCT_NAME_MAX_LENGTH = 50;
    private static final int QUANTITY_SOLD_MAX_LENGTH = 4;
    private static final int SALE_PRICE_MAX_LENGTH = 7; // including decimal point and cents
    private static final int SALE_DATE_MAX_LENGTH = 8;
    private static final int STORE_ID_MAX_LENGTH = 4;

    // Fields corresponding to COBOL definitions
    private String productName;
    private Integer quantitySold;
    private Double salePrice;
    private String saleDate;
    private Integer storeId;
    private String enter;
    private String cancel;

    // Getters and setters for each field
    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        if (productName.length() > PRODUCT_NAME_MAX_LENGTH) {
            throw new IllegalArgumentException("Product name exceeds maximum length of " + PRODUCT_NAME_MAX_LENGTH);
        }
        this.productName = productName;
    }

    public Integer getQuantitySold() {
        return quantitySold;
    }

    public void setQuantitySold(Integer quantitySold) {
        if (quantitySold.toString().length() > QUANTITY_SOLD_MAX_LENGTH) {
            throw new IllegalArgumentException("Quantity sold exceeds maximum length of " + QUANTITY_SOLD_MAX_LENGTH);
        }
        this.quantitySold = quantitySold;
    }

    public Double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(Double salePrice) {
        if (salePrice.toString().length() > SALE_PRICE_MAX_LENGTH) {
            throw new IllegalArgumentException("Sale price exceeds maximum length of " + SALE_PRICE_MAX_LENGTH);
        }
        this.salePrice = salePrice;
    }

    public String getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(String saleDate) {
        if (saleDate.length() > SALE_DATE_MAX_LENGTH) {
            throw new IllegalArgumentException("Sale date exceeds maximum length of " + SALE_DATE_MAX_LENGTH);
        }
        this.saleDate = saleDate;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        if (storeId.toString().length() > STORE_ID_MAX_LENGTH) {
            throw new IllegalArgumentException("Store ID exceeds maximum length of " + STORE_ID_MAX_LENGTH);
        }
        this.storeId = storeId;
    }

    public String getEnter() {
        return enter;
    }

    public void setEnter(String enter) {
        this.enter = enter;
    }

    public String getCancel() {
        return cancel;
    }

    public void setCancel(String cancel) {
        this.cancel = cancel;
    }
}
