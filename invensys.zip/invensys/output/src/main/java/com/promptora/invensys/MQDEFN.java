
/**
 * MQDEFN (Message Queue Definition)
 *
 * Original COBOL code:
 * <pre>
 *     01 MQ-CONN-HANDLE   PIC 9(9) COMP VALUE 0.
 *     01 MQ-QUEUE-HANDLE  PIC 9(9) COMP VALUE 0.
 *     01 RETURN-CODE      PIC 9(9) COMP VALUE 0.
 * </pre>
 */
public class MQDEFN {
    private long connHandle;
    private long queueHandle;
    private int returnCode;

    public static final long HANDLE_DEFAULT = 0L;

    /**
     * Constructor with default values
     */
    public MQDEFN() {
        this.connHandle = HANDLE_DEFAULT;
        this.queueHandle = HANDLE_DEFAULT;
        this.returnCode = 0;
    }

    /**
     * Getters and setters
     */
    public long getConnHandle() {
        return connHandle;
    }

    public void setConnHandle(long connHandle) {
        if (connHandle < 0) {
            throw new IllegalArgumentException("Invalid connection handle");
        }
        this.connHandle = connHandle;
    }

    // ... other getters and setters ...
}
