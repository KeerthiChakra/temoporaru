
/**
 * SLTRNWS class representing the sales transaction data.
 *
 * Original COBOL code:
 * 01 WS-PRODUCT-NAME      PIC X(50).
 * 01 WS-QUANTITY-SOLD     PIC 9(4).
 * 01 WS-SALE-PRICE        PIC 9(6)V99.
 * 01 WS-SALE-DATE         PIC 9(8).
 * 01 WS-STORE-ID          PIC 9(4).
 */
public class SLTRNWS {
    private String productName;
    private int quantitySold;
    private double salePrice;
    private long saleDate; // Representing the date in milliseconds since epoch
    private int storeId;

    public SLTRNWS() {}

    /**
     * Gets the product name.
     *
     * @return The product name (max 50 characters)
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets the product name.
     *
     * @param productName The product name (max 50 characters)
     */
    public void setProductName(String productName) {
        this.productName = productName.substring(0, Math.min(productName.length(), Constants.PRODUCT_NAME_MAX_LENGTH));
    }

    /**
     * Gets the quantity sold.
     *
     * @return The quantity sold
     */
    public int getQuantitySold() {
        return quantitySold;
    }

    /**
     * Sets the quantity sold.
     *
     * @param quantitySold The quantity sold (max 4 digits)
     */
    public void setQuantitySold(int quantitySold) {
        this.quantitySold = Math.min(quantitySold, Constants.QUANTITY_SOLD_MAX_VALUE);
    }

    /**
     * Gets the sale price.
     *
     * @return The sale price
     */
    public double getSalePrice() {
        return salePrice;
    }

    /**
     * Sets the sale price.
     *
     * @param salePrice The sale price (max 6 digits + 2 decimal places)
     */
    public void setSalePrice(double salePrice) {
        this.salePrice = Math.min(salePrice, Constants.SALE_PRICE_MAX_VALUE);
    }

    /**
     * Gets the sale date in milliseconds since epoch.
     *
     * @return The sale date
     */
    public long getSaleDate() {
        return saleDate;
    }

    /**
     * Sets the sale date in milliseconds since epoch.
     *
     * @param saleDate The sale date
     */
    public void setSaleDate(long saleDate) {
        this.saleDate = saleDate;
    }

    /**
     * Gets the store ID.
     *
     * @return The store ID
     */
    public int getStoreId() {
        return storeId;
    }

    /**
     * Sets the store ID.
     *
     * @param storeId The store ID (max 4 digits)
     */
    public void setStoreId(int storeId) {
        this.storeId = Math.min(storeId, Constants.STORE_ID_MAX_VALUE);
    }
}
